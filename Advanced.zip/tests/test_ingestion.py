from app.ingestion.loaders import extract_document_content
from app.ingestion.chunker import chunk_text

def test_extract_txt():
    content = b"Hello world"
    pages = extract_document_content(content, "test.txt")
    assert len(pages) == 1
    assert pages[0]["text"] == "Hello world"
    assert pages[0]["page_number"] is None

def test_extract_markdown():
    content = b"# Heading\nMarkdown text"
    pages = extract_document_content(content, "test.md")
    assert len(pages) == 1
    assert pages[0]["text"] == "# Heading\nMarkdown text"
    assert pages[0]["page_number"] is None

def test_extract_pdf(monkeypatch):
    from app.ingestion import loaders
    
    class MockPage:
        def extract_text(self):
            return "Hello PDF world"
            
    class MockPdfReader:
        def __init__(self, stream):
            self.pages = [MockPage()]
            
    monkeypatch.setattr(loaders, "PdfReader", MockPdfReader)
    
    pages = extract_document_content(b"dummy pdf bytes", "test.pdf")
    assert len(pages) == 1
    assert "Hello PDF world" in pages[0]["text"]
    assert pages[0]["page_number"] == 1

def test_chunk_text():
    text = "A" * 100
    chunks = chunk_text(text, chunk_size=40, overlap=10)
    # Expected chunks:
    # 0-40 (len 40)
    # 30-70 (len 40)
    # 60-100 (len 40)
    assert len(chunks) == 4
    assert len(chunks[0]) == 40
    assert len(chunks[1]) == 40
    assert len(chunks[2]) == 40
    assert len(chunks[3]) == 10
