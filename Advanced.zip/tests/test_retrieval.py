from app.retrieval.vector_store import FAISSVectorStore
from app.schemas.documents import RetrievedChunk
from app.retrieval.embeddings import embedding_service
import numpy as np

def test_faiss_vector_store():
    store = FAISSVectorStore()
    
    chunk1 = RetrievedChunk(chunk_id="1", document_id="d1", filename="f1.txt", file_type="txt", text="hello world")
    chunk2 = RetrievedChunk(chunk_id="2", document_id="d2", filename="f2.txt", file_type="txt", text="python programming")
    
    # We need matching dimension embeddings (384)
    # Actually, we can just use the real embedding service or dummy vectors
    emb1 = embedding_service.generate_embedding(chunk1.text)
    emb2 = embedding_service.generate_embedding(chunk2.text)
    
    store.add_chunks([chunk1, chunk2], np.array([emb1, emb2]))
    
    assert store.index.ntotal == 2
    
    # Search
    query_emb = embedding_service.generate_embedding("hello")
    results = store.search(query_emb, top_k=1)
    
    assert len(results) == 1
    assert results[0].document_id == "d1"
    
    # Filter search
    results = store.search(query_emb, top_k=1, document_id="d2")
    assert len(results) == 1
    assert results[0].document_id == "d2"

def test_reranker():
    from app.retrieval.reranker import reranker_service
    chunk1 = RetrievedChunk(chunk_id="1", document_id="d1", filename="f1.txt", file_type="txt", text="The capital of France is Paris.")
    chunk2 = RetrievedChunk(chunk_id="2", document_id="d1", filename="f1.txt", file_type="txt", text="I like eating apples.")
    
    # Mocking prediction for speed
    class MockModel:
        def predict(self, pairs):
            return [0.9 if "Paris" in pair[1] else 0.1 for pair in pairs]
    
    reranker_service.model = MockModel()
    reranker_service.available = True
    
    results = reranker_service.rerank("What is the capital of France?", [chunk1, chunk2], top_k=2)
    assert len(results) == 2
    assert results[0].chunk_id == "1"
    assert results[0].rerank_score == 0.9

def test_document_scoped_retrieval(monkeypatch):
    from app.retrieval.retriever import retrieve_and_rerank
    from app.retrieval import vector_store
    
    # Mock vector store search to ensure document_id is passed down
    def mock_search(query_embedding, top_k, document_id):
        assert document_id == "doc123"
        return [RetrievedChunk(chunk_id="1", document_id="doc123", filename="test.txt", file_type="txt", text="test")]
        
    monkeypatch.setattr(vector_store.vector_store, "search", mock_search)
    
    results = retrieve_and_rerank("test query", document_id="doc123", top_k=1)
    assert len(results) == 1
    assert results[0].document_id == "doc123"

