def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_upload_empty_file(client):
    response = client.post(
        "/documents/upload",
        files={"file": ("empty.txt", b"", "text/plain")}
    )
    assert response.status_code == 400
    assert "Empty file content" in response.json()["detail"]

def test_upload_oversized_file(client):
    # The max size is 10MB
    response = client.post(
        "/documents/upload",
        files={"file": ("large.txt", b"A" * (10 * 1024 * 1024 + 10), "text/plain")}
    )
    assert response.status_code == 400
    assert "File size exceeds the 10MB limit" in response.json()["detail"]

def test_upload_unsupported_file(client):
    response = client.post(
        "/documents/upload",
        files={"file": ("image.png", b"fake_image_data", "image/png")}
    )
    assert response.status_code == 400
    assert "Unsupported file format" in response.json()["detail"]

def test_upload_txt_file(client):
    response = client.post(
        "/documents/upload",
        files={"file": ("test.txt", b"This is a test document.", "text/plain")}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Document uploaded and indexed successfully"
    assert "document_id" in data
    assert data["chunk_count"] > 0
    
def test_list_documents(client):
    # Upload first
    client.post(
        "/documents/upload",
        files={"file": ("test2.txt", b"Another test.", "text/plain")}
    )
    response = client.get("/documents/")
    assert response.status_code == 200
    assert len(response.json()) > 0

def test_query_validation(client):
    # Empty query will trigger our manual 400 check because length is 3 but stripped is empty
    response = client.post("/query/", json={"query": "   ", "top_k": 5})
    assert response.status_code == 400

    # Invalid top_k will trigger Pydantic 422
    response = client.post("/query/", json={"query": "test", "top_k": 20})
    assert response.status_code == 422
    
def test_query_groundedness_failure(client, monkeypatch):
    from app.generation.groundedness import check_groundedness
    from app.api import routes_query
    from app.schemas.query import GroundednessResult

    class MockWorkflow:
        def invoke(self, state):
            return {
                "answer": "I cannot provide a fully grounded answer based on the provided documents. The information might be missing or unsupported.",
                "final_sources": [],
                "groundedness": GroundednessResult(supported=False, reason="Mock failure", unsupported_claims=["Mock claim"]),
                "rewritten_query": None
            }
    monkeypatch.setattr(routes_query, "app_workflow", MockWorkflow())

    response = client.post("/query/", json={"query": "test query"})
    assert response.status_code == 200
    data = response.json()
    assert data["groundedness"]["supported"] is False
    assert "cannot provide a fully grounded answer" in data["answer"]

def test_query_groundedness_success(client, monkeypatch):
    from app.api import routes_query
    from app.schemas.query import GroundednessResult

    class MockWorkflow:
        def invoke(self, state):
            return {
                "answer": "This is a supported answer.",
                "final_sources": [],
                "groundedness": GroundednessResult(supported=True, reason="Mock success", unsupported_claims=[]),
                "rewritten_query": None
            }
    monkeypatch.setattr(routes_query, "app_workflow", MockWorkflow())

    response = client.post("/query/", json={"query": "test query"})
    assert response.status_code == 200
    data = response.json()
    assert data["groundedness"]["supported"] is True
    assert data["answer"] == "This is a supported answer."

def test_query_rewrite_path(client, monkeypatch):
    from app.api import routes_query
    from app.schemas.query import GroundednessResult

    class MockWorkflow:
        def invoke(self, state):
            return {
                "answer": "This answer used a rewritten query.",
                "final_sources": [],
                "groundedness": GroundednessResult(supported=True, reason="Mock success", unsupported_claims=[]),
                "rewritten_query": "better test query"
            }
    monkeypatch.setattr(routes_query, "app_workflow", MockWorkflow())

    response = client.post("/query/", json={"query": "bad query"})
    assert response.status_code == 200
    data = response.json()
    assert data["rewritten_query"] == "better test query"

