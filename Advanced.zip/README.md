# Advanced-A: Production-Style RAG Application

## Overview
This is a production-style Retrieval-Augmented Generation (RAG) assistant built as part of the ShadowFox AI Engineer Internship - Advanced Level.

## Features
- **Multi-format Document Ingestion:** Supports PDF, TXT, and Markdown files.
- **Document-Scoped Retrieval:** Filter queries to specific documents or query all documents.
- **Reranking:** Improves retrieval quality by reranking FAISS candidates using a CrossEncoder.
- **Query Refinement:** LangGraph workflow evaluates retrieval quality and optionally rewrites queries.
- **Groundedness Check:** Verifies if generated answers are supported by retrieved context.
- **Citations:** Every answer provides citations mapped to retrieved chunks.
- **FastAPI Backend:** Clean typed API endpoints using Pydantic.
- **Streamlit Frontend:** User-friendly UI displaying retrieval stages, chunks, and scores.

## Architecture
See `docs/architecture.md` for a detailed breakdown.

## Tech Stack
- **Backend:** FastAPI, Pydantic, Python 3.12
- **Frontend:** Streamlit
- **RAG & Graph:** LangGraph, FAISS, sentence-transformers
- **LLM:** Groq API (Configurable Model)
- **Containerization:** Docker & Docker Compose

## Run the project

1. Copy `.env.example` to `.env` and set `GROQ_API_KEY`.
2. Create virtual environment: `python -m venv .venv`
3. Activate environment and install dependencies:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
4. Start the application:
   ```powershell
   python run.py
   ```
The application will automatically start both the FastAPI backend and Streamlit frontend services in the background, wait for them to be ready, and open the Streamlit interface in your browser.
## Docker Run Instructions
1. Set `GROQ_API_KEY` in `.env`.
2. Build and run: `docker-compose up --build`
3. Access UI at http://localhost:8501 and API docs at http://localhost:8000/docs
