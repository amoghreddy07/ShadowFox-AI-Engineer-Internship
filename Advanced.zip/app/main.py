from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import routes_health, routes_documents, routes_query
from app.core.logging_config import setup_logging

setup_logging()

app = FastAPI(
    title="Advanced RAG API",
    description="Production-style RAG architecture for Advanced Level",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_health.router, tags=["Health"])
app.include_router(routes_documents.router, prefix="/documents", tags=["Documents"])
app.include_router(routes_query.router, prefix="/query", tags=["Query"])

@app.get("/", tags=["Health"])
def root():
    return {
        "name": "Advanced RAG Assistant",
        "status": "ok",
        "docs": "/docs"
    }
