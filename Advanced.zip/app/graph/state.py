from typing import List, Optional, TypedDict
from app.schemas.documents import RetrievedChunk
from app.schemas.query import GroundednessResult

class GraphState(TypedDict):
    query: str
    document_id: Optional[str]
    top_k: int
    
    # State variables
    rewritten_query: Optional[str]
    retrieved_chunks: List[RetrievedChunk]
    rewrite_count: int
    
    # Outputs
    answer: str
    groundedness: Optional[GroundednessResult]
    final_sources: List[RetrievedChunk]
