from langgraph.graph import StateGraph, END
from app.graph.state import GraphState
from app.graph.nodes import retrieve_node, generate_node, check_groundedness_node


def route_after_eval(state: GraphState) -> str:
    chunks = state.get("retrieved_chunks", [])
    is_weak = False
    
    if not chunks:
        is_weak = True
    else:
        best_chunk = chunks[0]
        if best_chunk.rerank_score is not None and best_chunk.rerank_score < -2.0:
            is_weak = True
        elif best_chunk.score is not None and best_chunk.score < 0.2:
            is_weak = True

    rewrite_count = state.get("rewrite_count", 0)
    
    if is_weak and rewrite_count < 1:
        return "rewrite"
    return "generate"

def get_workflow():
    workflow = StateGraph(GraphState)
    
    workflow.add_node("retrieve", retrieve_node)
    
    # We will split evaluate and rewrite for cleaner routing
    # Let's just create a rewrite node here to keep it simple, instead of doing it inside evaluate_retrieval_node
    from app.generation.groq_client import groq_service
    from app.generation.prompts import REWRITE_PROMPT
    
    def rewrite_node(state: GraphState) -> GraphState:
        state["rewrite_count"] = state.get("rewrite_count", 0) + 1
        query_to_use = state.get("rewritten_query") or state["query"]
        rewritten = groq_service.generate_completion(
            system_prompt="You are a helpful query rewriter.",
            user_prompt=REWRITE_PROMPT.format(query=query_to_use)
        )
        state["rewritten_query"] = rewritten.strip()
        return state

    workflow.add_node("rewrite", rewrite_node)
    workflow.add_node("generate", generate_node)
    workflow.add_node("check_groundedness", check_groundedness_node)
    
    workflow.set_entry_point("retrieve")
    
    workflow.add_conditional_edges(
        "retrieve",
        route_after_eval,
        {
            "rewrite": "rewrite",
            "generate": "generate"
        }
    )
    
    workflow.add_edge("rewrite", "retrieve")
    workflow.add_edge("generate", "check_groundedness")
    workflow.add_edge("check_groundedness", END)
    
    return workflow.compile()

app_workflow = get_workflow()
