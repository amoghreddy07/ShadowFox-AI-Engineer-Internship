from app.graph.state import GraphState
from app.retrieval.retriever import retrieve_and_rerank
from app.generation.groq_client import groq_service
from app.generation.prompts import SYSTEM_PROMPT, REWRITE_PROMPT
from app.generation.groundedness import check_groundedness

def retrieve_node(state: GraphState) -> GraphState:
    query_to_use = state.get("rewritten_query") or state["query"]
    chunks = retrieve_and_rerank(
        query=query_to_use,
        document_id=state.get("document_id"),
        top_k=state["top_k"]
    )
    state["retrieved_chunks"] = chunks
    return state

def generate_node(state: GraphState) -> GraphState:
    chunks = state.get("retrieved_chunks", [])
    query = state.get("rewritten_query") or state["query"]
    
    context = ""
    for i, chunk in enumerate(chunks):
        context += f"Source [{i+1}]: {chunk.text}\n\n"
        
    system_prompt = SYSTEM_PROMPT.format(context=context)
    
    answer = groq_service.generate_completion(
        system_prompt=system_prompt,
        user_prompt=query
    )
    
    state["answer"] = answer
    state["final_sources"] = chunks
    return state

def check_groundedness_node(state: GraphState) -> GraphState:
    answer = state.get("answer", "")
    chunks = state.get("final_sources", [])
    
    result = check_groundedness(answer, chunks)
    state["groundedness"] = result
    
    if not result.supported:
        # If unsupported, we overwrite the answer with a safe fallback
        state["answer"] = "I cannot provide a fully grounded answer based on the provided documents. The information might be missing or unsupported."
    
    return state
