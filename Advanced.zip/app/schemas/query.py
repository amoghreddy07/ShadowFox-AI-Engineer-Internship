from pydantic import BaseModel, Field
from typing import Optional, List
from .documents import RetrievedChunk

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000, description="The query text, must not be completely empty.")
    document_id: Optional[str] = Field(None, description="Optional document UUID to scope the search.")
    top_k: int = Field(5, ge=1, le=10, description="Number of results to retrieve (1-10).")

class SourceCitation(BaseModel):
    filename: str
    page_number: Optional[int] = None
    score: Optional[float] = None
    text_snippet: str

class GroundednessResult(BaseModel):
    supported: bool
    reason: str
    unsupported_claims: List[str]

class QueryResponse(BaseModel):
    answer: str
    sources: List[SourceCitation]
    retrieved_chunks: List[RetrievedChunk]
    groundedness: Optional[GroundednessResult] = None
    rewritten_query: Optional[str] = None
