from pydantic import BaseModel, Field
from typing import List, Optional

class DocumentMetadata(BaseModel):
    document_id: str
    filename: str
    file_type: str
    page_number: Optional[int] = None

class ChunkMetadata(DocumentMetadata):
    chunk_id: str

class ExtractedDocument(BaseModel):
    document_id: str
    filename: str
    file_type: str
    pages: List[dict]  # list of dicts like {"page_number": int, "text": str} or {"text": str} for unpaginated

class RetrievedChunk(BaseModel):
    chunk_id: str
    document_id: str
    filename: str
    file_type: str
    page_number: Optional[int] = None
    text: str
    score: Optional[float] = None
    rerank_score: Optional[float] = None

class DocumentUploadResponse(BaseModel):
    message: str
    document_id: str
    filename: str
    chunk_count: int
