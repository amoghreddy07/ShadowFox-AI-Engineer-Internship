import faiss
import numpy as np
from typing import List, Optional, Dict, Any
from app.schemas.documents import RetrievedChunk
from app.core.config import settings

class FAISSVectorStore:
    def __init__(self):
        self.dimension = settings.VECTOR_DIMENSION
        self.index = faiss.IndexFlatIP(self.dimension)
        self.metadata_store: Dict[int, RetrievedChunk] = {}
        self.current_id = 0

    def add_chunks(self, chunks: List[RetrievedChunk], embeddings: np.ndarray):
        if len(chunks) != embeddings.shape[0]:
            raise ValueError("Number of chunks and embeddings must match.")
        
        if embeddings.shape[0] == 0:
            return

        self.index.add(embeddings)
        
        for i, chunk in enumerate(chunks):
            self.metadata_store[self.current_id + i] = chunk
            
        self.current_id += len(chunks)

    def search(self, query_embedding: np.ndarray, top_k: int = 5, document_id: Optional[str] = None) -> List[RetrievedChunk]:
        if self.index.ntotal == 0:
            return []

        # If document_id is specified, we might need to search more to filter, 
        # or implement a custom filter. FAISS IndexFlatIP doesn't support metadata filtering natively.
        # We will fetch a larger k and filter manually for simplicity, or we could rebuild a temporary index.
        # Given this is a simple local app, filtering after fetching a large k is acceptable, 
        # or we just fetch everything and filter, then sort.
        
        k_to_fetch = self.index.ntotal if document_id else min(top_k, self.index.ntotal)
        
        distances, indices = self.index.search(query_embedding.reshape(1, -1), k_to_fetch)
        
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx == -1:
                continue
            chunk = self.metadata_store[idx]
            
            if document_id and chunk.document_id != document_id:
                continue
                
            chunk_copy = chunk.model_copy()
            chunk_copy.score = float(dist)
            results.append(chunk_copy)
            
            if len(results) >= top_k and not document_id:
                break
                
        # if document_id was used, sort and slice
        if document_id:
            results = sorted(results, key=lambda x: x.score or 0, reverse=True)[:top_k]
            
        return results

    def remove_document(self, document_id: str):
        # FAISS IndexFlatIP does not support removing vectors easily.
        # We will rebuild the index.
        new_index = faiss.IndexFlatIP(self.dimension)
        new_metadata_store = {}
        new_current_id = 0
        
        vectors = []
        for idx, chunk in self.metadata_store.items():
            if chunk.document_id != document_id:
                # We need the original vectors, but we didn't store them. 
                # This is a limitation. To support delete, we should store vectors or reconstruct them.
                # Actually, we can reconstruct the index from self.index.reconstruct(idx) if it's supported,
                # but IndexFlatIP does support reconstruct!
                vector = self.index.reconstruct(idx)
                vectors.append(vector)
                new_metadata_store[new_current_id] = chunk
                new_current_id += 1
                
        if vectors:
            new_index.add(np.array(vectors))
            
        self.index = new_index
        self.metadata_store = new_metadata_store
        self.current_id = new_current_id

    def get_all_documents(self) -> List[Dict[str, Any]]:
        docs = {}
        for chunk in self.metadata_store.values():
            if chunk.document_id not in docs:
                docs[chunk.document_id] = {
                    "document_id": chunk.document_id,
                    "filename": chunk.filename,
                    "file_type": chunk.file_type,
                    "chunk_count": 0
                }
            docs[chunk.document_id]["chunk_count"] += 1
        return list(docs.values())

vector_store = FAISSVectorStore()
