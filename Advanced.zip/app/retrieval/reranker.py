from sentence_transformers import CrossEncoder
from typing import List
from app.schemas.documents import RetrievedChunk
from app.core.config import settings

class RerankerService:
    def __init__(self):
        try:
            self.model = CrossEncoder(settings.RERANKER_MODEL)
            self.available = True
        except Exception as e:
            print(f"Warning: Reranker model could not be loaded. Error: {e}")
            self.available = False

    def rerank(self, query: str, chunks: List[RetrievedChunk], top_k: int = 5) -> List[RetrievedChunk]:
        if not self.available or not chunks:
            return chunks[:top_k]
            
        pairs = [[query, chunk.text] for chunk in chunks]
        scores = self.model.predict(pairs)
        
        for i, chunk in enumerate(chunks):
            chunk.rerank_score = float(scores[i])
            
        chunks_sorted = sorted(chunks, key=lambda x: x.rerank_score or -999.0, reverse=True)
        return chunks_sorted[:top_k]

reranker_service = RerankerService()
