from sentence_transformers import SentenceTransformer
import numpy as np
from app.core.config import settings

class EmbeddingService:
    def __init__(self):
        self.model = SentenceTransformer(settings.EMBEDDING_MODEL)
        
    def generate_embedding(self, text: str) -> np.ndarray:
        embedding = self.model.encode(text, normalize_embeddings=True)
        return np.array(embedding).astype('float32')
        
    def generate_embeddings(self, texts: list[str]) -> np.ndarray:
        embeddings = self.model.encode(texts, normalize_embeddings=True)
        return np.array(embeddings).astype('float32')

embedding_service = EmbeddingService()
