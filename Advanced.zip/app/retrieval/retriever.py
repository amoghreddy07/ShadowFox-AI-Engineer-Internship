from typing import List, Optional
from app.schemas.documents import RetrievedChunk
from app.retrieval.vector_store import vector_store
from app.retrieval.embeddings import embedding_service
from app.retrieval.reranker import reranker_service

def retrieve_and_rerank(query: str, document_id: Optional[str] = None, top_k: int = 5, candidates_k: int = 15) -> List[RetrievedChunk]:
    # 1. Generate query embedding
    query_embedding = embedding_service.generate_embedding(query)
    
    # 2. Retrieve candidates from FAISS
    candidates = vector_store.search(query_embedding, top_k=candidates_k, document_id=document_id)
    
    if not candidates:
        return []
        
    # 3. Rerank
    final_results = reranker_service.rerank(query, candidates, top_k=top_k)
    
    return final_results
