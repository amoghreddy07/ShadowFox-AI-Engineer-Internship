from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List, Dict, Any
import uuid

from app.schemas.documents import DocumentUploadResponse, ExtractedDocument
from app.ingestion.loaders import extract_document_content
from app.ingestion.chunker import process_document
from app.retrieval.embeddings import embedding_service
from app.retrieval.vector_store import vector_store

router = APIRouter()

@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Empty filename")
        
    ext = file.filename.split(".")[-1].lower()
    if ext not in ["pdf", "txt", "md"]:
        raise HTTPException(status_code=400, detail="Unsupported file format")
        
    MAX_SIZE = 10 * 1024 * 1024 # 10MB
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Empty file content")
        
    if len(content) > MAX_SIZE:
        raise HTTPException(status_code=400, detail="File size exceeds the 10MB limit")
        
    document_id = str(uuid.uuid4())
    
    try:
        pages = extract_document_content(content, file.filename)
        doc = ExtractedDocument(
            document_id=document_id,
            filename=file.filename,
            file_type=ext,
            pages=pages
        )
        
        chunks = process_document(doc)
        if not chunks:
            raise HTTPException(status_code=400, detail="No extractable text found in the document")
            
        texts = [chunk.text for chunk in chunks]
        embeddings = embedding_service.generate_embeddings(texts)
        
        vector_store.add_chunks(chunks, embeddings)
        
        return DocumentUploadResponse(
            message="Document uploaded and indexed successfully",
            document_id=document_id,
            filename=file.filename,
            chunk_count=len(chunks)
        )
    except HTTPException:
        raise
    except Exception as e:
        # Hide raw internal errors from the user
        raise HTTPException(status_code=500, detail="An internal error occurred during document processing")
@router.get("/", response_model=List[Dict[str, Any]])
def list_documents():
    return vector_store.get_all_documents()

@router.delete("/{document_id}")
def delete_document(document_id: str):
    try:
        vector_store.remove_document(document_id)
        return {"message": "Document removed"}
    except Exception as e:
        raise HTTPException(status_code=500, detail="An internal error occurred while removing the document")
