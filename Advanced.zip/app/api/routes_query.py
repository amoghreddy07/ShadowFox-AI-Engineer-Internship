from fastapi import APIRouter, HTTPException
from typing import List, Optional
from pydantic import BaseModel

from app.schemas.query import QueryRequest, QueryResponse, SourceCitation, RetrievedChunk
from app.graph.workflow import app_workflow

router = APIRouter()

@router.post("/", response_model=QueryResponse)
def query_documents(request: QueryRequest):
    if not request.query.strip():
        raise HTTPException(status_code=400, detail="Empty query")

    initial_state = {
        "query": request.query,
        "document_id": request.document_id,
        "top_k": request.top_k,
        "rewritten_query": None,
        "retrieved_chunks": [],
        "rewrite_count": 0,
        "answer": "",
        "groundedness": None,
        "final_sources": []
    }
    
    try:
        final_state = app_workflow.invoke(initial_state)
        
        sources = []
        for chunk in final_state.get("final_sources", []):
            sources.append(SourceCitation(
                filename=chunk.filename,
                page_number=chunk.page_number,
                score=chunk.rerank_score if chunk.rerank_score is not None else chunk.score,
                text_snippet=chunk.text
            ))
            
        return QueryResponse(
            answer=final_state.get("answer", ""),
            sources=sources,
            retrieved_chunks=final_state.get("final_sources", []),
            groundedness=final_state.get("groundedness"),
            rewritten_query=final_state.get("rewritten_query")
        )
        
    except Exception as e:
        import logging
        logging.error(f"Query processing error: {str(e)}", exc_info=True)
        # Hide raw internal errors
        raise HTTPException(status_code=500, detail="An internal error occurred while processing the query")
