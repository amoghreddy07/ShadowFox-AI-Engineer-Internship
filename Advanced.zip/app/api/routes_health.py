from fastapi import APIRouter
from app.schemas.responses import HealthResponse

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
def health_check():
    return HealthResponse(status="ok", message="API is running")
