import os
from groq import Groq
from app.core.config import settings

class GroqService:
    def __init__(self):
        self.client = None
        
    def get_client(self):
        if self.client is None:
            # We initialize lazily to allow tests to run without API key
            api_key = settings.GROQ_API_KEY
            if not api_key:
                api_key = "dummy_key_for_tests"
            self.client = Groq(api_key=api_key)
        return self.client

    def generate_completion(self, system_prompt: str, user_prompt: str, response_format: dict = None) -> str:
        client = self.get_client()
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        kwargs = {
            "model": settings.GROQ_MODEL,
            "messages": messages,
            "temperature": 0.0
        }
        
        if response_format:
            kwargs["response_format"] = response_format

        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content

    def generate_completion_stream(self, system_prompt: str, user_prompt: str):
        client = self.get_client()
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        stream = client.chat.completions.create(
            model=settings.GROQ_MODEL,
            messages=messages,
            temperature=0.0,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content

groq_service = GroqService()
