import json
from typing import List
from app.schemas.query import GroundednessResult
from app.schemas.documents import RetrievedChunk
from app.generation.groq_client import groq_service
from app.generation.prompts import GROUNDEDNESS_PROMPT

def check_groundedness(answer: str, chunks: List[RetrievedChunk]) -> GroundednessResult:
    if not chunks:
        # If no chunks were provided, the answer should be unsupported unless it says it doesn't know
        if "do not contain sufficient information" in answer.lower():
            return GroundednessResult(supported=True, reason="Correctly identified lack of information.", unsupported_claims=[])
        return GroundednessResult(supported=False, reason="No context provided.", unsupported_claims=["Entire answer"])

    context = ""
    for i, chunk in enumerate(chunks):
        context += f"Source [{i+1}]: {chunk.text}\n\n"
        
    prompt = GROUNDEDNESS_PROMPT.format(context=context, answer=answer)
    
    try:
        response_text = groq_service.generate_completion(
            system_prompt="You are a JSON-only evaluator.",
            user_prompt=prompt,
            response_format={"type": "json_object"}
        )
        data = json.loads(response_text)
        return GroundednessResult(
            supported=data.get("supported", False),
            reason=data.get("reason", "Failed to parse reason"),
            unsupported_claims=data.get("unsupported_claims", [])
        )
    except Exception as e:
        print(f"Groundedness check failed: {e}")
        # Mark as unsupported if the check fails to prevent claiming it is grounded
        return GroundednessResult(
            supported=False, 
            reason="Verification failed due to an internal error.", 
            unsupported_claims=["Verification process failed"]
        )
