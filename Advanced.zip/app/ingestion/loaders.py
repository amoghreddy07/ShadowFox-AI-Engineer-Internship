from typing import List, Dict, Any
from pypdf import PdfReader
import io

def load_pdf(file_bytes: bytes) -> List[Dict[str, Any]]:
    reader = PdfReader(io.BytesIO(file_bytes))
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text()
        if text:
            pages.append({"page_number": i + 1, "text": text})
    return pages

def load_txt(file_bytes: bytes) -> List[Dict[str, Any]]:
    text = file_bytes.decode("utf-8")
    return [{"page_number": None, "text": text}]

def load_markdown(file_bytes: bytes) -> List[Dict[str, Any]]:
    # A simple loader for now, could be enhanced to parse headers.
    text = file_bytes.decode("utf-8")
    return [{"page_number": None, "text": text}]

def extract_document_content(file_bytes: bytes, filename: str) -> List[Dict[str, Any]]:
    if filename.lower().endswith(".pdf"):
        return load_pdf(file_bytes)
    elif filename.lower().endswith(".txt"):
        return load_txt(file_bytes)
    elif filename.lower().endswith(".md"):
        return load_markdown(file_bytes)
    else:
        raise ValueError("Unsupported file type")
