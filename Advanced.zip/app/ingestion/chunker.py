import uuid
from typing import List, Dict, Any
from app.core.config import settings
from app.schemas.documents import ExtractedDocument, RetrievedChunk
from app.ingestion.cleaner import clean_text

def chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks

def process_document(document: ExtractedDocument) -> List[RetrievedChunk]:
    chunks = []
    for page in document.pages:
        page_number = page.get("page_number")
        text = clean_text(page.get("text", ""))
        if not text:
            continue
            
        # Simplistic chunking strategy
        text_chunks = chunk_text(text, settings.CHUNK_SIZE, settings.CHUNK_OVERLAP)
        
        for chunk_text_content in text_chunks:
            chunk_id = str(uuid.uuid4())
            chunks.append(RetrievedChunk(
                chunk_id=chunk_id,
                document_id=document.document_id,
                filename=document.filename,
                file_type=document.file_type,
                page_number=page_number,
                text=chunk_text_content
            ))
            
    return chunks
