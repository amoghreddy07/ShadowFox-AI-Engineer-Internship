import re

def clean_text(text: str) -> str:
    # Basic text cleaning: remove excessive whitespace and null characters
    text = text.replace('\x00', '')
    text = re.sub(r'\s+', ' ', text)
    return text.strip()
