import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    GROQ_API_KEY: str = ""
    GROQ_MODEL: str = "openai/gpt-oss-20b"
    
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    RERANKER_MODEL: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    
    VECTOR_DIMENSION: int = 384
    
    class Config:
        env_file = ".env"

settings = Settings()
