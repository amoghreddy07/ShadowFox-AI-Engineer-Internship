import requests
import time

def verify():
    base_url = "http://127.0.0.1:8000"
    
    # 1. Test /
    print("Testing / ...")
    r = requests.get(f"{base_url}/")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}"
    print(r.json())
    
    # 2. Test /health
    print("Testing /health ...")
    r = requests.get(f"{base_url}/health")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}"
    print(r.json())
    
    # 3. Test /docs
    print("Testing /docs ...")
    r = requests.get(f"{base_url}/docs")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}"
    print("Docs accessible.")

    # 4. Upload a document
    print("Creating dummy txt document...")
    with open("dummy.txt", "w") as f:
        f.write("The quick brown fox jumps over the lazy dog. ShadowFox internship is awesome.")
    
    print("Uploading dummy.txt ...")
    with open("dummy.txt", "rb") as f:
        r = requests.post(f"{base_url}/documents/upload", files={"file": f})
    assert r.status_code == 200, f"Upload failed: {r.status_code} - {r.text}"
    print(r.json())
    
    # 5. Query
    print("Testing query ...")
    payload = {
        "query": "What is awesome?",
        "top_k": 3
    }
    r = requests.post(f"{base_url}/query/", json=payload)
    assert r.status_code == 200, f"Query failed: {r.status_code} - {r.text}"
    result = r.json()
    print("Answer:", result.get("answer"))
    print("Sources:", len(result.get("sources", [])))
    print("Groundedness:", result.get("groundedness"))
    
    print("\nAll workflow tests passed!")

if __name__ == "__main__":
    verify()
