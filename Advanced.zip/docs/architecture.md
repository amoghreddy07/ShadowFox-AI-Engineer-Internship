# Architecture

## Overview
This application separates concerns cleanly into a backend API (FastAPI) and a frontend UI (Streamlit), simulating a real production deployment.

## Ingestion Pipeline
1. **Document Upload (PDF/TXT/MD):** Processed in-memory.
2. **Text Extraction & Cleaning:** Specific loaders handle different formats.
3. **Chunking:** Fixed-size chunking with overlap (configurable). Preserves metadata (page numbers, filename).
4. **Embeddings:** `all-MiniLM-L6-v2` produces normalized 384-dimensional embeddings.
5. **FAISS Indexing:** Inner-product indexing (`IndexFlatIP`) is used. Metadata is stored alongside vector IDs.

## Retrieval & Query Pipeline (LangGraph)
1. **Initial Retrieval:** Candidate chunks are retrieved from FAISS. If a `document_id` is specified, results are strictly filtered.
2. **Quality Evaluation:** LangGraph evaluates the retrieval quality based on vector similarities.
3. **Query Refinement:** If context is weak (low similarity), the query is dynamically rewritten by the LLM and retrieved again (bounded to 1 retry).
4. **Reranking:** The initial FAISS candidate set is reranked using a CrossEncoder (`ms-marco-MiniLM-L-6-v2`) to surface the absolute best chunks.
5. **Grounded Generation:** The LLM generates a response strictly using the reranked context. Prompting strongly discourages hallucinations.
6. **Groundedness Check:** A secondary LLM call evaluates if the generated answer is supported by the context. If unsupported claims are found, the UI clearly displays this fallback warning.

## Why these technologies?
- **FastAPI:** Fast, async-ready, built-in validation (Pydantic), and automatic OpenAPI docs.
- **Streamlit:** Rapid UI prototyping with enough capability to show granular retrieval details.
- **FAISS:** Lightweight, fast, local vector indexing.
- **LangGraph:** Enables complex, cyclical agentic workflows (e.g. rewrite -> retrieve loop).
- **Reranking:** Drastically improves relevance compared to single-stage vector search.
