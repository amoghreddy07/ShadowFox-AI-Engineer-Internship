# Demo Script (3-5 Minutes)

1. **Start Application:** `docker-compose up`
2. **UI Overview:** Show the Streamlit frontend.
3. **Ingestion (PDF):** Upload `AI Engineer Internship Task List.pdf`. Show it appears in the sidebar list.
4. **Ingestion (TXT/MD):** Upload a sample markdown or text file.
5. **Basic Query:** Ask "What are the requirements for the Advanced level?".
6. **Show Retrieval Details:** Expand the "Retrieval Details" section in the UI. Point out the extracted chunks, their scores, and the cross-encoder reranking scores.
7. **Document Scoping:** Select the PDF in the sidebar dropdown. Ask a question specific to that document.
8. **Groundedness / Hallucination Check:** Ask something not in the documents (e.g. "What is the capital of France?"). The UI should show "Unsupported" in the Groundedness check or answer safely.
9. **Query Refinement:** Ask a vaguely worded question that fails initial retrieval (if applicable) and show the "Rewritten Query" in the details panel.
10. **Backend Tour:** Open `http://localhost:8000/docs` to show the clean FastAPI Swagger documentation and typed Pydantic schemas.
