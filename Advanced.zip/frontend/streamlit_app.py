import streamlit as st
import requests
import json

import os

API_URL = os.getenv("API_URL", "http://localhost:8000")

st.set_page_config(page_title="Advanced RAG Assistant", layout="wide")

st.title("Advanced RAG Assistant")

if "documents" not in st.session_state:
    st.session_state["documents"] = []

def fetch_documents():
    try:
        response = requests.get(f"{API_URL}/documents/")
        if response.status_code == 200:
            st.session_state["documents"] = response.json()
    except Exception as e:
        st.error(f"Failed to fetch documents: {e}")

st.sidebar.header("Document Management")

uploaded_file = st.sidebar.file_uploader("Upload PDF, TXT, or MD", type=["pdf", "txt", "md"])
if st.sidebar.button("Upload"):
    if uploaded_file is not None:
        with st.spinner("Uploading and indexing..."):
            try:
                files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
                response = requests.post(f"{API_URL}/documents/upload", files=files)
                if response.status_code == 200:
                    st.sidebar.success(f"Uploaded {uploaded_file.name} successfully!")
                    fetch_documents()
                else:
                    st.sidebar.error(f"Upload failed: {response.text}")
            except Exception as e:
                st.sidebar.error(f"Error: {e}")
    else:
        st.sidebar.warning("Please select a file first.")

st.sidebar.subheader("Available Documents")
fetch_documents()

document_options = {"All Documents": None}
for doc in st.session_state["documents"]:
    st.sidebar.write(f"- {doc['filename']} ({doc['chunk_count']} chunks)")
    document_options[doc['filename']] = doc['document_id']
    if st.sidebar.button(f"Delete {doc['filename']}", key=f"del_{doc['document_id']}"):
        requests.delete(f"{API_URL}/documents/{doc['document_id']}")
        fetch_documents()
        st.rerun()

st.sidebar.subheader("Retrieval Settings")
selected_doc_name = st.sidebar.selectbox("Scope to Document", options=list(document_options.keys()))
top_k = st.sidebar.slider("Top K Results", min_value=1, max_value=10, value=3)

# Main chat interface
query = st.text_input("Ask a question about the uploaded documents:")
if st.button("Ask"):
    if not query.strip():
        st.warning("Please enter a query.")
    else:
        with st.spinner("Retrieving and generating answer..."):
            payload = {
                "query": query,
                "document_id": document_options[selected_doc_name],
                "top_k": top_k
            }
            try:
                response = requests.post(f"{API_URL}/query/", json=payload)
                if response.status_code == 200:
                    result = response.json()
                    
                    st.subheader("Answer")
                    st.write(result["answer"])
                    
                    # Display citations
                    if result["sources"]:
                        st.markdown("**Sources:**")
                        for i, source in enumerate(result["sources"]):
                            st.write(f"[{i+1}] {source['filename']} (Score: {source['score']:.4f})")
                            
                    # Groundedness Check
                    if result.get("groundedness"):
                        groundedness = result["groundedness"]
                        st.subheader("Groundedness Check")
                        if groundedness["supported"]:
                            st.success(f"Supported: {groundedness['reason']}")
                        else:
                            st.error(f"Unsupported: {groundedness['reason']}")
                            if groundedness["unsupported_claims"]:
                                st.write("Unsupported claims:")
                                for claim in groundedness["unsupported_claims"]:
                                    st.write(f"- {claim}")
                    
                    # Retrieval Details Expander
                    with st.expander("Retrieval Details"):
                        if result.get("rewritten_query"):
                            st.write(f"**Rewritten Query:** {result['rewritten_query']}")
                        
                        st.write("**Retrieved Chunks:**")
                        for i, chunk in enumerate(result.get("retrieved_chunks", [])):
                            st.markdown(f"**Chunk {i+1}** (File: {chunk['filename']}, Page: {chunk.get('page_number', 'N/A')})")
                            st.markdown(f"Score: {chunk.get('score')}, Rerank Score: {chunk.get('rerank_score')}")
                            st.text(chunk['text'])
                            
                else:
                    st.error(f"Query failed: {response.text}")
            except Exception as e:
                st.error(f"Error: {e}")
