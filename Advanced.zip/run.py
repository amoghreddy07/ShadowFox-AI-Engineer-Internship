"""One-command launcher for Advanced RAG Assistant.

Starts FastAPI (backend) and Streamlit (frontend) using the currently
active Python interpreter, with explicit working directory, visible
subprocess output, and HTTP health-check based startup detection.
"""
import subprocess
import sys
import time
import socket
import webbrowser
import os
import threading
import urllib.request
import urllib.error
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
PYTHON_EXE = sys.executable  # active venv / project interpreter

FASTAPI_HOST = "127.0.0.1"
FASTAPI_PORT = 8000
STREAMLIT_PORT = 8501

# FastAPI loads embedding + reranker models at import time (~28s measured
# on this machine). Give it a generous timeout so a slow-but-healthy
# startup is not misreported as "Failed to start FastAPI".
FASTAPI_TIMEOUT = 180
STREAMLIT_TIMEOUT = 120


def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


def http_ok(url, timeout=3):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return 200 <= r.status < 400
    except Exception:
        return False


def wait_for_http(url, timeout, label, proc=None, log_lines=None):
    """Poll an HTTP URL until it returns 2xx/3xx or timeout.

    If proc exits early, stop waiting and return False so the caller can
    report the captured output instead of a generic failure message.
    """
    start = time.time()
    while time.time() - start < timeout:
        if proc is not None and proc.poll() is not None:
            return False
        if http_ok(url):
            return True
        time.sleep(1)
    return http_ok(url)


def _drain_stream(pipe, prefix, log_lines, echo=True):
    """Forward subprocess output to console with a prefix; retain for errors."""
    try:
        for line in iter(pipe.readline, ""):
            if not line:
                break
            log_lines.append(line)
            if echo:
                # prefix keeps FastAPI vs Streamlit output distinguishable
                sys.stdout.write(f"{prefix} {line}")
                sys.stdout.flush()
    except Exception:
        pass
    finally:
        try:
            pipe.close()
        except Exception:
            pass


def start_process(cmd, log_prefix):
    proc = subprocess.Popen(
        cmd,
        cwd=str(PROJECT_ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    log_lines: list = []
    t = threading.Thread(
        target=_drain_stream,
        args=(proc.stdout, log_prefix, log_lines),
        daemon=True,
    )
    t.start()
    return proc, log_lines


def print_captured_output(label, log_lines):
    print(f"\n===== {label} captured output (complete) =====", flush=True)
    if log_lines:
        for line in log_lines:
            sys.stdout.write(line)
    else:
        print("(no output captured)", flush=True)
    print(f"===== end {label} output =====\n", flush=True)


def main():
    print(f"Project root : {PROJECT_ROOT}", flush=True)
    print(f"Python       : {PYTHON_EXE}", flush=True)

    fastapi_proc = None
    fastapi_logs: list = []
    streamlit_proc = None
    streamlit_logs: list = []

    fastapi_url = f"http://{FASTAPI_HOST}:{FASTAPI_PORT}"
    fastapi_health = f"{fastapi_url}/health"
    streamlit_url = f"http://127.0.0.1:{STREAMLIT_PORT}"

    # --- Port conflict handling: reuse healthy services, refuse duplicates ---
    fastapi_reused = False
    streamlit_reused = False

    if is_port_in_use(FASTAPI_PORT):
        if http_ok(fastapi_health):
            print(f"Port {FASTAPI_PORT} already serves a healthy FastAPI, reusing it.", flush=True)
            fastapi_reused = True
        else:
            print(
                f"Error: Port {FASTAPI_PORT} is already in use by something that "
                f"does not answer {fastapi_health}. Stop it and retry.",
                flush=True,
            )
            sys.exit(1)

    if is_port_in_use(STREAMLIT_PORT):
        if http_ok(streamlit_url):
            print(f"Port {STREAMLIT_PORT} already serves Streamlit, reusing it.", flush=True)
            streamlit_reused = True
        else:
            print(
                f"Error: Port {STREAMLIT_PORT} is already in use by something that "
                f"does not answer {streamlit_url}. Stop it and retry.",
                flush=True,
            )
            sys.exit(1)

    try:
        # --- Start FastAPI first (heavy model load), wait until healthy ---
        if not fastapi_reused:
            print("Starting FastAPI...", flush=True)
            fastapi_proc, fastapi_logs = start_process(
                [
                    PYTHON_EXE, "-m", "uvicorn", "app.main:app",
                    "--host", FASTAPI_HOST, "--port", str(FASTAPI_PORT),
                ],
                "[FastAPI]",
            )
            if not wait_for_http(
                fastapi_health, FASTAPI_TIMEOUT, "FastAPI",
                proc=fastapi_proc, log_lines=fastapi_logs,
            ):
                # Only report failure when it actually failed.
                if fastapi_proc.poll() is not None:
                    print(
                        f"FastAPI process exited with code {fastapi_proc.returncode}.",
                        flush=True,
                    )
                else:
                    print(
                        f"FastAPI did not answer {fastapi_health} within "
                        f"{FASTAPI_TIMEOUT}s. It may still be loading models.",
                        flush=True,
                    )
                    fastapi_proc.terminate()
                    try:
                        fastapi_proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        fastapi_proc.kill()
                print_captured_output("FastAPI", fastapi_logs)
                print("Failed to start FastAPI (see complete output above).", flush=True)
                sys.exit(1)
            print(f"FastAPI is ready at {fastapi_url}", flush=True)
        else:
            print(f"FastAPI is ready at {fastapi_url} (already running)", flush=True)

        # --- Then start Streamlit ---
        if not streamlit_reused:
            print("Starting Streamlit...", flush=True)
            streamlit_proc, streamlit_logs = start_process(
                [
                    PYTHON_EXE, "-m", "streamlit", "run",
                    "frontend/streamlit_app.py",
                    "--server.port", str(STREAMLIT_PORT),
                    "--server.headless", "true",
                ],
                "[Streamlit]",
            )
            if not wait_for_http(
                streamlit_url, STREAMLIT_TIMEOUT, "Streamlit",
                proc=streamlit_proc, log_lines=streamlit_logs,
            ):
                if streamlit_proc.poll() is not None:
                    print(
                        f"Streamlit process exited with code {streamlit_proc.returncode}.",
                        flush=True,
                    )
                else:
                    print(
                        f"Streamlit did not answer {streamlit_url} within "
                        f"{STREAMLIT_TIMEOUT}s.",
                        flush=True,
                    )
                    streamlit_proc.terminate()
                    try:
                        streamlit_proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        streamlit_proc.kill()
                print_captured_output("Streamlit", streamlit_logs)
                print("Failed to start Streamlit (see complete output above).", flush=True)
                if fastapi_proc is not None:
                    fastapi_proc.terminate()
                    try:
                        fastapi_proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        fastapi_proc.kill()
                sys.exit(1)
            print(f"Streamlit is ready at {streamlit_url}", flush=True)
        else:
            print(f"Streamlit is ready at {streamlit_url} (already running)", flush=True)

        print("Opening browser...", flush=True)
        try:
            webbrowser.open(streamlit_url)
        except Exception as e:
            print(f"Could not open browser automatically: {e}", flush=True)
            print(f"Open manually: {streamlit_url}", flush=True)

        procs = []
        if fastapi_proc is not None:
            procs.append(("FastAPI", fastapi_proc, fastapi_logs))
        if streamlit_proc is not None:
            procs.append(("Streamlit", streamlit_proc, streamlit_logs))

        if not procs:
            print("Both services were already running. Nothing to monitor. Exiting.", flush=True)
            return

        print("Press Ctrl+C to stop both servers.", flush=True)
        # Monitor: if either child dies unexpectedly, report with full logs.
        while True:
            for name, proc, logs in procs:
                rc = proc.poll()
                if rc is not None:
                    print(f"{name} process exited unexpectedly with code {rc}.", flush=True)
                    print_captured_output(name, logs)
                    # Shut down the other child before exiting.
                    for oname, oproc, _ in procs:
                        if oproc is not proc and oproc.poll() is None:
                            oproc.terminate()
                    for _, oproc, _ in procs:
                        try:
                            oproc.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            oproc.kill()
                    sys.exit(rc if rc != 0 else 1)
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nShutting down services...", flush=True)
        for name, proc, _ in [("FastAPI", fastapi_proc, None), ("Streamlit", streamlit_proc, None)]:
            if proc is not None and proc.poll() is None:
                try:
                    proc.terminate()
                except Exception as e:
                    print(f"Error terminating {name}: {e}", flush=True)
        for proc in [fastapi_proc, streamlit_proc]:
            if proc is not None:
                try:
                    proc.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except Exception:
                        pass
        print("Services stopped cleanly.", flush=True)


if __name__ == "__main__":
    main()
