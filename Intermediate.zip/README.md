# DocQA - Document-Based Q&A Assistant

**ShadowFox AI Engineer Internship - Intermediate Level**

A practical, retrieval-based Question Answering assistant. Upload one or more
PDF/TXT documents, ask questions in plain language, and get answers that are
**grounded in the uploaded content** - with every supporting passage displayed
next to the answer.

---

## 1. Project Overview

Large language models answer from their general training memory. That is fine
for open conversation, but wrong for questions about *your* documents: the
model cannot know your lecture notes, reports, or manuals, and will confidently
make things up.

DocQA solves this with a real **RAG (Retrieval-Augmented Generation)** workflow:
instead of sending an entire document to the LLM, the system

1. extracts and splits documents into small chunks,
2. converts those chunks into vector embeddings,
3. retrieves only the chunks that are semantically similar to the question,
4. forces the LLM to answer **using only those retrieved chunks**,
5. shows the user exactly which passages were used.

## 2. Problem Being Solving

Build a usable AI application that answers questions about uploaded text/PDF
files by first identifying relevant content from those files, then generating
a grounded response - demonstrating document ingestion, chunking, embeddings,
vector retrieval, and grounded generation working together as one pipeline.

## 3. Features

- Upload one or more **TXT** or **PDF** documents (multi-document)
- Text extraction with **page numbers preserved for PDFs**
- Encoding-tolerant TXT reading (UTF-8, BOM, CP1252, Latin-1 fallback)
- Structure-aware **chunking with overlap** (paragraphs -> sentences)
- **Embedding generation** with a configurable sentence-transformers model
- **Vector similarity search** (FAISS, NumPy fallback)
- Top-K retrieval with a configurable **similarity threshold**
- **Grounded answer generation** through the Groq LLM API
- **Context visibility**: source filename, page/chunk id, and similarity score
  for every retrieved passage
- Index status, per-document chunk counts, and rebuild control in the sidebar
- Handling for invalid files, empty files, image-only PDFs, empty questions,
  weak retrieval, missing API keys, and LLM failures - all with plain-language
  messages (no raw stack traces in the UI)

## 4. Tech Stack

| Layer         | Choice                              | Why                                                        |
| ------------- | ----------------------------------- | ---------------------------------------------------------- |
| UI            | Streamlit                           | Fast, simple Python UI for upload/query flows              |
| PDF parsing   | PyPDF (`pypdf`)                     | Lightweight, reliable text extraction with page info       |
| Embeddings    | Sentence Transformers               | Local embedding models, no embedding API needed            |
| Vector index  | FAISS (`faiss-cpu`) + NumPy fallback | Exact cosine similarity, tiny dependency footprint         |
| LLM           | Groq (`groq`)                       | Official Groq SDK, fast Llama inference via `GROQ_API_KEY`   |
| Config        | `python-dotenv`                     | Secrets stay in `.env`, never in code                      |
| Tests         | pytest                              | Offline unit/integration tests, no paid API calls          |

## 5. Architecture

```
                        Streamlit UI (app.py)
             +--------------------------------------+
             |  Sidebar: upload, settings, status   |
             |  Main: question, answer, sources     |
             +------------------+-------------------+
                                |
        +-----------------------+------------------------+
        |                       |                        |
        v                       v                        v
+-----------------+   +------------------+   +----------------------+
| document_loader |-->|     chunker      |-->|     embeddings       |
| TXT/PDF extract |   | sentences+overlap|   | sentence-transformers|
| validate/clean  |   | source + page md |   | L2-normalized vecs   |
+-----------------+   +------------------+   +----------+-----------+
                                                       |
                                                       v
                                            +----------------------+
        user question ------------------>   |    vector_store      |
        (question embedding via            | FAISS IndexFlatIP    |
         same embedder)                     | (NumPy fallback)     |
                                            +----------+-----------+
                                                       |
                                                       v
                                            +----------------------+
                                            |     retriever        |
                                            | top-k + threshold    |
                                            +----------+-----------+
                                                       |
                          +----------------------------+
                          v                            v
                 +------------------+        +---------------------+
                 | weak context?    | yes    |      qa_engine      |
                 | -> inform user,  |------->| SYSTEM PROMPT +     |
                 |    show candidates|       | QUESTION + CONTEXT  |
                 +------------------+        | (Groq LLM)         |
                                             +----------+----------+
                                                        |
                                                        v
                                             Answer + Retrieved Sources
```

## 6. RAG Workflow

```
Document Upload
    |
    v
Text Extraction (TXT/PDF, page-aware)
    |
    v
Text Cleaning (normalize whitespace, strip control chars)
    |
    v
Chunking (paragraph/sentence aware, size + overlap)
    |
    v
Embedding Generation (sentence-transformers, L2-normalized)
    |
    v
Vector / Semantic Index (FAISS inner product = cosine similarity)
    |
    v
User Question  ->  Question Embedding  ->  Similarity Retrieval (Top-K)
    |
    v
Threshold filter (drop weak matches)
    |
    +--> no relevant context --> inform user + show candidates (no LLM call)
    |
    v
Grounded Answer Generation (LLM sees ONLY retrieved context)
    |
    v
Answer + Retrieved Sources/Context (filename, page/chunk, similarity, text)
```

## 7. Document Ingestion (`src/document_loader.py`)

- **Validation first**: only `.txt` and `.pdf` are accepted; anything else is
  rejected with a clear message (Streamlit also restricts the file picker).
- **TXT**: bytes are decoded with a fallback chain
  `utf-8-sig -> utf-8 -> cp1252 -> latin-1`, so common encoding problems do not
  crash the app.
- **PDF**: `pypdf` extracts text **per page**, keeping the 1-based page number
  with each text unit. Encrypted PDFs (that cannot be opened with an empty
  password) and corrupted PDFs raise friendly errors. PDFs with **no
  extractable text** (scanned/image-only) are rejected with an explicit message
  instead of silently indexing nothing.
- **Cleaning**: newlines normalized, control characters removed, repeated
  whitespace collapsed.
- **Empty input**: 0-byte files and whitespace-only files are rejected.

Every failure raises a `DocumentError` subclass with a message that is safe to
show in the UI; technical details are logged, not displayed.

## 8. Chunking Strategy (`src/chunker.py`)

**Defaults: chunk size = 800 characters, overlap = 150 characters**
(configurable in the sidebar and via `CHUNK_SIZE` / `CHUNK_OVERLAP`).

How it splits (never random):

1. Split each text unit into **paragraphs**, then into **sentences**.
2. Greedily pack whole sentences into chunks up to 800 characters.
3. When a new chunk starts, carry over the **tail of the previous chunk**
   (~150 characters, trimmed to a word boundary) so meaning that crosses a
   boundary is not lost.
4. Sentences longer than the chunk size are hard-split with the same stride.

Why these values:

- **800 chars (~150-200 tokens)** is large enough to capture a complete idea or
  explanation, and small enough that the embedding represents one focused
  topic - too-large chunks blur the vector and hurt similarity ranking.
- **150 chars (~20% overlap)** keeps continuity across boundaries so a key
  sentence is unlikely to be cut in half between two chunks.
- Chunking is done **per PDF page** so page metadata stays exact.

Each chunk stores: **source filename**, **chunk id** (1-based per document),
**page number** (PDF only), and the **text**.

## 9. Embedding Model (`src/embeddings.py`)

- Default model: **`sentence-transformers/all-MiniLM-L6-v2`**
  (384 dimensions, fast, strong general-purpose retrieval quality, ~90 MB,
  downloaded once and cached locally).
- Any other sentence-transformers model name can be set via the sidebar or the
  `EMBEDDING_MODEL` environment variable.
- Vectors are **L2-normalized**, so cosine similarity and inner product are
  equivalent.
- The model is loaded lazily and cached with `st.cache_resource` - it is loaded
  **once per process**, and embeddings are only regenerated when the documents
  or chunk settings change (tracked with a content hash signature).
- Embedding code is fully separated from extraction and retrieval; it exposes a
  small `encode(texts) -> vectors` interface.

## 10. Vector Search Approach (`src/vector_store.py`)

- **FAISS `IndexFlatIP`** (exact inner product over normalized vectors =
  exact cosine similarity). No approximate structures are needed at this scale,
  so results are deterministic and precise.
- If FAISS cannot be imported, the store transparently falls back to a NumPy
  dot-product implementation with identical behavior (the active backend is
  shown in the sidebar).
- Vectors are re-normalized at build and query time, so scores are always
  cosine similarity in `[-1, 1]` (reported to three decimals in the UI).

## 11. Retrieval Process (`src/retriever.py`)

For each question:

1. Validate the question (empty/whitespace-only questions are rejected).
2. Embed the question with the **same model** used for the chunks.
3. Search the index for the **Top-K** most similar chunks (default **K = 4**,
   slider 1-10).
4. Drop any chunk whose cosine similarity is below the **threshold
   (default 0.25)** - these are considered too weak to ground an answer on.
5. Pass the surviving chunks (with scores and metadata) to answer generation.

If **no chunk passes the threshold**, the LLM is **not called**: the user is
told the documents may not contain the answer, and the best candidates are
still displayed for transparency. Retrieval only ever searches the uploaded
documents - never external information.

Why 0.25: for normalized MiniLM embeddings, unrelated passages typically score
well below 0.2-0.3, while topically related passages usually score above
0.35-0.5. 0.25 filters obvious noise without discarding moderately relevant
context. It is a heuristic, exposed as a slider so it can be tuned.

## 12. Grounded Answer Generation (`src/qa_engine.py`)

The prompt has three explicit parts:

```
[SYSTEM]
  You are a document-based Q&A assistant.
  Answer ONLY from the RETRIEVED CONTEXT.
  Do not invent. If the answer is not present, reply that the
  uploaded documents do not contain enough information.

[USER]
  RETRIEVED CONTEXT:
  ----------------------------------------
  [1] Source: notes.pdf | Page: 4 | Chunk: 12 | Similarity: 0.612
  <chunk text>
  [2] Source: guide.txt | Chunk: 3 | Similarity: 0.547
  <chunk text>
  ----------------------------------------

  QUESTION:
  <user question>
```

Guarantees enforced in code, not just in prose:

- The question is **never sent to the LLM without retrieved context**
  (`generate_answer` raises if the context list is empty).
- The LLM sees only the retrieved passages - never the full documents and no
  tool/knowledge access.
- LLM configuration comes from environment variables (`GROQ_API_KEY`,
  `GROQ_MODEL`) via the official Groq Python SDK (`from groq import Groq`).

## 13. How Unsupported / Hallucinated Answers Are Reduced

Grounding is applied at **five layers**:

1. **Retrieval first** - the model only ever sees passages taken from the
   uploaded documents, not open-ended memory.
2. **Threshold filter** - weak/below-threshold passages are excluded, and if
   nothing clears the bar, **no generation call happens at all**.
3. **Hard prompt constraints** - explicit instructions to use only the supplied
   context, not to invent, and to use a fixed refusal sentence when the answer
   is absent.
4. **Code-level enforcement** - generation refuses to run with empty context.
5. **Context visibility** - the user (and evaluator) can read the exact
   passages behind every answer and check them directly.

**Honest limitation:** these measures *reduce* unsupported responses; they do
**not guarantee zero hallucinations**. An LLM can still misread or overstate a
genuinely retrieved passage, and retrieval itself can return the wrong chunk.
Always read the displayed sources for critical use.

## 14. Installation

Requirements: Python 3.10+ (validated on 3.12).

```bash
git clone <your-repo-url>
cd Intermediate-A

python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

The embedding model (~90 MB) downloads automatically on first run.

## 15. Environment Variables

```bash
cp .env.example .env
# then edit .env and set your real key
```

| Variable           | Required | Default                              | Purpose                                  |
| ------------------ | -------- | ------------------------------------ | ---------------------------------------- |
| `GROQ_API_KEY`     | Yes (for answers) | -                        | Groq API key (https://console.groq.com/keys) |
| `GROQ_MODEL`       | No       | `llama-3.1-8b-instant`               | Groq chat model ID                       |
| `EMBEDDING_MODEL`  | No       | `sentence-transformers/all-MiniLM-L6-v2` | Sentence-transformers model         |
| `CHUNK_SIZE`       | No       | `800`                                | Chunk size (characters)                  |
| `CHUNK_OVERLAP`    | No       | `150`                                | Chunk overlap (characters)               |
| `TOP_K`            | No       | `4`                                  | Retrieval count                          |
| `MIN_SIMILARITY`   | No       | `0.25`                               | Cosine similarity threshold              |

Example `.env`:

```bash
GROQ_API_KEY=gsk_your_key_here
GROQ_MODEL=llama-3.1-8b-instant
```

`.env` is listed in `.gitignore` and must never be committed. Only
`.env.example` (placeholders) lives in the repository.

## 16. How to Run

```bash
streamlit run app.py
```

Then open the URL shown in the terminal (default: `http://localhost:8501`).

## 17. Example Usage

1. In the **sidebar**, upload e.g. `ml_notes.pdf` and `reading_list.txt`.
2. Wait for **"Index ready: N chunks from 2 document(s)"**.
3. In the main area, type a question your documents answer, e.g.
   *"What is the effect of the learning rate?"*
4. Click **Ask**.
5. Read the **Answer**, then inspect **Retrieved Sources**:

```
Answer
...
The learning rate controls the step size of each parameter update...

Retrieved Sources
1. ml_notes.pdf - Page 4 - Similarity: 0.612
   "Gradient descent updates model weights to minimize loss. The learning
    rate controls the step size of each parameter update..."
2. reading_list.txt - Chunk 3 - Similarity: 0.487
   "..."
```

Ask a question the documents do not cover (e.g. *"What is the capital of
France?"*): if nothing clears the similarity threshold, the app tells you the
documents do not contain the information and does not fabricate an answer.

## 18. Testing

```bash
python -m pytest tests/ -v
```

| File                        | Covers                                                                 |
| --------------------------- | ---------------------------------------------------------------------- |
| `tests/test_document_loader.py` | TXT (UTF-8/BOM/CP1252), PDF extraction + page numbers, unsupported types, empty/whitespace files, image-only PDF, corrupt PDF, cleaning |
| `tests/test_chunking.py`    | Chunk size limits, word-boundary splits, overlap behavior, hard-split stride, source/page/id metadata, parameter validation |
| `tests/test_retrieval.py`   | Index build, ranked results, relevance, Top-K limit, threshold filtering, empty query, embedding failure, dimension mismatch, empty store |
| `tests/test_qa_engine.py`   | Grounding instructions in prompt, QUESTION/CONTEXT separation, context labels, client integration, missing key, empty question, no-context refusal, API/rate-limit/empty-response errors |
| `tests/test_pipeline.py`    | Full load -> chunk -> embed -> retrieve -> answer flow with the **real** embedding model and a fake LLM (auto-skips if the model is unavailable) |

Design of the suite:

- **No paid API calls** - LLM behavior is tested with an injected fake client.
- Retrieval tests use a deterministic in-process embedder, so they run offline
  and in milliseconds.
- **40 tests, all passing** on Python 3.12.

Beyond the automated suite, the UI workflow was validated end-to-end with
Streamlit's `AppTest` harness: multi-file upload (TXT + PDF + empty + corrupt),
index build, answerable question with source display, empty question, weak
retrieval, no documents, and missing API key - all handled with the expected
messages.

## 19. Project Structure

```
Intermediate-A/
|
+-- app.py                     # Streamlit UI + orchestration (upload/index/ask/display)
+-- requirements.txt
+-- .env.example               # placeholder configuration (copy to .env)
+-- .gitignore                 # ignores .env and other local artifacts
+-- README.md
|
+-- src/
|   +-- __init__.py
|   +-- config.py              # defaults (chunk size, top-k, models, threshold)
|   +-- document_loader.py     # validation, TXT/PDF extraction, cleaning
|   +-- chunker.py             # structure-aware chunking with overlap + metadata
|   +-- embeddings.py          # sentence-transformers wrapper (encode API)
|   +-- vector_store.py        # FAISS/NumPy cosine index
|   +-- retriever.py           # question embedding, top-k, threshold filter
|   +-- qa_engine.py           # grounded prompt + Groq generation
|
+-- tests/
|   +-- conftest.py            # fake embedder + fake LLM client
|   +-- test_document_loader.py
|   +-- test_chunking.py
|   +-- test_retrieval.py
|   +-- test_qa_engine.py
|   +-- test_pipeline.py
```

Responsibilities are deliberately separated: extraction, chunking, embedding,
indexing, retrieval, and generation know nothing about Streamlit and can each
be tested or swapped independently - while staying simple enough for an
intermediate-level project.

## 20. Limitations

- **Grounding reduces, but does not eliminate, hallucinations.** The model can
  still misinterpret a retrieved passage; the visible sources exist so you can
  verify.
- The vector index lives **in memory per browser session**: refreshing the page
  or restarting the server requires re-uploading documents (by design for this
  scope - no external database).
- **No OCR**: scanned/image-only PDFs have no extractable text and are
  rejected with a clear message.
- **No conversation memory**: each question is answered independently.
- The default embedding model is **English-centric**; other languages work less
  well unless you swap `EMBEDDING_MODEL`.
- Similarity thresholding is a **heuristic**; borderline passages can be
  filtered or admitted incorrectly (it is exposed as a slider).
- Exact (flat) vector search is used - perfectly fine for this scale, not for
  millions of chunks.
- Advanced-level concerns (reranking, query rewriting, streaming, auth,
  Docker/FastAPI/LangGraph orchestration) are intentionally **out of scope**
  for this Intermediate task.
