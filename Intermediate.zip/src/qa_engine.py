"""Grounded answer generation.

Builds a structured prompt that strictly separates the user QUESTION from
the RETRIEVED CONTEXT and instructs the model to answer only from that
context, then calls the Groq chat completions API via the official Groq
Python SDK.
"""

from __future__ import annotations

import logging
import os

from .config import DEFAULT_LLM_MODEL
from .retriever import RetrievedChunk

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a document-based question answering assistant.
You must answer the user's QUESTION using ONLY the RETRIEVED CONTEXT supplied with it.

Rules:
1. Use only information that appears in the RETRIEVED CONTEXT.
2. Do not invent facts and do not rely on outside/general knowledge for unsupported claims.
3. If the RETRIEVED CONTEXT does not contain the answer, reply exactly:
   "The uploaded documents do not contain enough information to answer this question."
4. Keep the answer concise, relevant, and in the same language as the question.
5. When useful, refer to context labels such as [1], [2] to point at sources.
"""

NO_CONTEXT_MESSAGE = (
    "The uploaded documents do not contain enough information to answer this question."
)


class QAError(Exception):
    """Base class for user-facing answer-generation errors."""


class MissingAPIKeyError(QAError):
    """No Groq API key is configured."""


class AnswerGenerationError(QAError):
    """The Groq call failed or returned nothing usable."""


def format_context(retrieved: list[RetrievedChunk]) -> str:
    """Render retrieved chunks as labeled context blocks."""
    blocks = []
    for index, item in enumerate(retrieved, start=1):
        chunk = item.chunk
        header = f"[{index}] Source: {chunk.source}"
        if chunk.page is not None:
            header += f" | Page: {chunk.page}"
        header += f" | Chunk: {chunk.chunk_id} | Similarity: {item.score:.3f}"
        blocks.append(f"{header}\n{chunk.text}")
    return "\n\n".join(blocks)


def build_messages(question: str, retrieved: list[RetrievedChunk]) -> list[dict]:
    """Build the chat messages for a grounded answer.

    The payload clearly separates QUESTION from RETRIEVED CONTEXT so the
    model can only ground its answer in the supplied passages.
    """
    context = format_context(retrieved)
    user_prompt = (
        f"RETRIEVED CONTEXT:\n"
        f"{'-' * 40}\n"
        f"{context}\n"
        f"{'-' * 40}\n\n"
        f"QUESTION:\n"
        f"{question.strip()}"
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]


def _friendly_error(exc: Exception, model: str) -> str:
    name = type(exc).__name__
    message = str(exc)
    if "Authentication" in name or "401" in message:
        return "Groq rejected the API key. Check GROQ_API_KEY."
    if "Permission" in name or "403" in message:
        return "Groq denied access. Check your GROQ_API_KEY and account permissions."
    if "RateLimit" in name or "429" in message:
        return "Groq rate limit reached. Wait a moment and try again."
    if "APIConnection" in name or "Timeout" in name or "Connect" in name:
        return "Could not reach Groq. Check your internet connection."
    if "NotFound" in name or "404" in message:
        return f"Model '{model}' was not found by Groq. Check GROQ_MODEL."
    if "BadRequest" in name or "400" in message:
        return (
            f"Groq rejected the request for model '{model}'. "
            "Check GROQ_MODEL (the model may be unavailable or deprecated)."
        )
    return "Answer generation failed. Please try again."


def generate_answer(
    question: str,
    retrieved: list[RetrievedChunk],
    *,
    api_key: str | None = None,
    model: str | None = None,
    client=None,
) -> str:
    """Generate an answer grounded in ``retrieved`` chunks via Groq.

    The model is read from ``GROQ_MODEL`` (falling back to a default Groq
    chat model) and the key from ``GROQ_API_KEY``. ``client`` may be
    injected for testing; otherwise a ``groq.Groq`` client is created.

    Raises:
        QAError: empty question, no context, missing key, or API failure.
    """
    if question is None or not str(question).strip():
        raise QAError("Please enter a question before asking for an answer.")
    if not retrieved:
        raise QAError(
            "Cannot generate an answer without retrieved document context."
        )

    model_name = model or os.getenv("GROQ_MODEL") or DEFAULT_LLM_MODEL

    if client is None:
        key = api_key if api_key is not None else os.getenv("GROQ_API_KEY")
        if not key or not str(key).strip():
            raise MissingAPIKeyError(
                "Groq API key is not configured. Add GROQ_API_KEY to your .env file."
            )
        try:
            from groq import Groq
        except ImportError as exc:
            raise QAError(
                "The 'groq' package is not installed. "
                "Run `pip install -r requirements.txt`."
            ) from exc
        try:
            client = Groq(api_key=str(key).strip())
        except Exception as exc:  # noqa: BLE001 - surfaced as QAError
            logger.exception("Failed to create Groq client")
            raise AnswerGenerationError(
                "Could not initialize the Groq client. Check your configuration."
            ) from exc

    messages = build_messages(question, retrieved)
    try:
        response = client.chat.completions.create(model=model_name, messages=messages)
        content = response.choices[0].message.content
    except Exception as exc:  # noqa: BLE001 - surfaced as QAError
        logger.exception("Groq call failed (model=%s)", model_name)
        raise AnswerGenerationError(_friendly_error(exc, model_name)) from exc

    if not content or not str(content).strip():
        raise AnswerGenerationError(
            "The language model returned an empty response. Please try again."
        )
    return str(content).strip()
