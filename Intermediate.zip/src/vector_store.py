"""Vector index for similarity search over document chunks.

Uses FAISS (``IndexFlatIP`` = exact inner product) when available and falls
back to a NumPy cosine-similarity implementation otherwise. Vectors are
re-normalized at build/search time so scores are always cosine similarity
in [-1, 1].
"""

from __future__ import annotations

import logging

import numpy as np

from .chunker import Chunk
from .embeddings import EmbeddingError

logger = logging.getLogger(__name__)


class VectorStoreError(Exception):
    """Raised when indexing or searching fails."""


def _normalize(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (matrix / norms).astype(np.float32)


class VectorStore:
    """Holds chunk metadata plus their embeddings and answers top-k queries."""

    def __init__(self) -> None:
        self.chunks: list[Chunk] = []
        self.dim: int | None = None
        self.backend: str | None = None
        self._vectors: np.ndarray | None = None
        self._faiss_index = None

    def __len__(self) -> int:
        return len(self.chunks)

    def build(self, chunks: list[Chunk], embedder) -> None:
        """Embed all chunks and build the similarity index."""
        if not chunks:
            raise VectorStoreError("There are no document chunks to index.")

        try:
            vectors = embedder.encode([chunk.text for chunk in chunks])
        except EmbeddingError as exc:
            raise VectorStoreError(str(exc)) from exc

        vectors = np.asarray(vectors, dtype=np.float32)
        if vectors.ndim != 2 or vectors.shape[0] != len(chunks):
            raise VectorStoreError(
                "Embedding output did not match the number of chunks."
            )

        vectors = _normalize(vectors)
        self.chunks = list(chunks)
        self._vectors = vectors
        self.dim = int(vectors.shape[1])

        try:
            import faiss

            index = faiss.IndexFlatIP(self.dim)
            index.add(vectors)
            self._faiss_index = index
            self.backend = "faiss"
        except Exception:  # noqa: BLE001 - numpy fallback is fully functional
            logger.info("FAISS unavailable; using NumPy similarity backend")
            self._faiss_index = None
            self.backend = "numpy"

    def search(self, query_vector: np.ndarray, top_k: int) -> list[tuple[Chunk, float]]:
        """Return the top-k (chunk, cosine similarity) pairs for a query vector."""
        if not self.chunks or self._vectors is None or self.dim is None:
            return []

        query = np.asarray(query_vector, dtype=np.float32).reshape(1, -1)
        if query.shape[1] != self.dim:
            raise VectorStoreError(
                f"Query embedding has dimension {query.shape[1]}, expected {self.dim}."
            )
        query = _normalize(query)

        k = max(1, min(int(top_k), len(self.chunks)))
        if self._faiss_index is not None:
            scores, ids = self._faiss_index.search(query, k)
            return [
                (self.chunks[int(idx)], float(score))
                for score, idx in zip(scores[0], ids[0])
                if int(idx) >= 0
            ]

        similarities = self._vectors @ query[0]
        order = np.argsort(-similarities)[:k]
        return [(self.chunks[int(i)], float(similarities[int(i)])) for i in order]
