"""Application configuration.

Values can be overridden through environment variables (see `.env.example`).
"""

from __future__ import annotations

import os

SUPPORTED_EXTENSIONS = (".txt", ".pdf")
SUPPORTED_UPLOAD_TYPES = ["txt", "pdf"]

DEFAULT_EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
)
DEFAULT_CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))
DEFAULT_CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "150"))
DEFAULT_TOP_K = int(os.getenv("TOP_K", "4"))
DEFAULT_MIN_SIMILARITY = float(os.getenv("MIN_SIMILARITY", "0.25"))
DEFAULT_LLM_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
