"""Question-side retrieval: embed the query and fetch relevant chunks."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from .chunker import Chunk
from .config import DEFAULT_MIN_SIMILARITY, DEFAULT_TOP_K
from .embeddings import EmbeddingError
from .vector_store import VectorStore, VectorStoreError

logger = logging.getLogger(__name__)


class RetrievalError(Exception):
    """Raised when retrieval fails for technical reasons."""


class EmptyQueryError(RetrievalError):
    """The user submitted an empty or whitespace-only question."""


@dataclass
class RetrievedChunk:
    """A chunk selected for a query, with its cosine similarity score."""

    chunk: Chunk
    score: float


class Retriever:
    """Embeds questions and searches the vector store built from uploads."""

    def __init__(
        self,
        embedder,
        vector_store: VectorStore,
        top_k: int = DEFAULT_TOP_K,
        min_similarity: float = DEFAULT_MIN_SIMILARITY,
    ):
        self.embedder = embedder
        self.vector_store = vector_store
        self.top_k = max(1, int(top_k))
        self.min_similarity = float(min_similarity)

    def search(self, query: str, top_k: int | None = None) -> list[RetrievedChunk]:
        """Return the top-k chunks by cosine similarity (no threshold applied)."""
        if query is None or not str(query).strip():
            raise EmptyQueryError("Please enter a question before searching.")

        try:
            query_vector = self.embedder.encode([str(query).strip()])[0]
        except EmbeddingError as exc:
            raise RetrievalError(str(exc)) from exc

        try:
            pairs = self.vector_store.search(query_vector, top_k or self.top_k)
        except VectorStoreError as exc:
            raise RetrievalError(f"Vector search failed: {exc}") from exc

        return [RetrievedChunk(chunk=chunk, score=score) for chunk, score in pairs]

    def retrieve(self, query: str) -> list[RetrievedChunk]:
        """Return relevant chunks, dropping any below ``min_similarity``.

        Filtering weak matches keeps the answer-generation step fed only with
        plausibly relevant context (weak-context handling / grounding).
        """
        results = self.search(query)
        kept = [r for r in results if r.score >= self.min_similarity]
        logger.info(
            "Retrieval: %d/%d candidates above similarity threshold %.2f",
            len(kept),
            len(results),
            self.min_similarity,
        )
        return kept
