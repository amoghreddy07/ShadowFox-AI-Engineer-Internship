"""Document ingestion: validation, text extraction, and basic cleaning.

Supports TXT and PDF uploads. Every failure mode raises a subclass of
``DocumentError`` carrying a message that is safe to show in the UI.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from io import BytesIO

from .config import SUPPORTED_EXTENSIONS

logger = logging.getLogger(__name__)

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class DocumentError(Exception):
    """Base class for user-facing document loading errors."""


class UnsupportedFileTypeError(DocumentError):
    """The uploaded file type is not supported."""


class EmptyDocumentError(DocumentError):
    """The file is empty or contains no usable/extractable text."""


class ExtractionError(DocumentError):
    """The file could not be parsed (corrupt, encrypted, unreadable)."""


@dataclass
class TextUnit:
    """A block of cleaned text from a document, optionally tied to a page."""

    text: str
    page: int | None = None


@dataclass
class LoadedDocument:
    """A successfully loaded document and its extracted text units."""

    filename: str
    units: list[TextUnit] = field(default_factory=list)

    @property
    def page_count(self) -> int:
        return len({unit.page for unit in self.units if unit.page is not None}) or 1


def clean_text(text: str) -> str:
    """Normalize whitespace and strip control characters from raw text."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _CONTROL_CHARS.sub(" ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" *\n *", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _decode_txt(data: bytes) -> str:
    """Decode TXT bytes, trying common encodings before falling back."""
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _load_txt(filename: str, data: bytes) -> list[TextUnit]:
    cleaned = clean_text(_decode_txt(data))
    if not cleaned:
        raise EmptyDocumentError(f"'{filename}' contains no usable text.")
    return [TextUnit(text=cleaned, page=None)]


def _extract_pdf(filename: str, data: bytes) -> list[TextUnit]:
    from pypdf import PdfReader

    try:
        reader = PdfReader(BytesIO(data))
        if reader.is_encrypted:
            try:
                decrypted = reader.decrypt("")
            except Exception as exc:  # noqa: BLE001 - surfaced as DocumentError
                raise ExtractionError(
                    f"'{filename}' is password-protected and cannot be read."
                ) from exc
            if not decrypted:
                raise ExtractionError(
                    f"'{filename}' is password-protected and cannot be read."
                )
        units: list[TextUnit] = []
        for page_number, page in enumerate(reader.pages, start=1):
            try:
                raw = page.extract_text() or ""
            except Exception:  # noqa: BLE001 - a single bad page should not kill the file
                logger.warning("Failed to extract text from page %s of %s", page_number, filename)
                raw = ""
            cleaned = clean_text(raw)
            if cleaned:
                units.append(TextUnit(text=cleaned, page=page_number))
        return units
    except DocumentError:
        raise
    except Exception as exc:  # noqa: BLE001 - surfaced as DocumentError
        logger.exception("Failed to parse PDF '%s'", filename)
        raise ExtractionError(
            f"Could not read '{filename}'. The file may be corrupted or not a valid PDF."
        ) from exc


def load_document(filename: str, data: bytes) -> LoadedDocument:
    """Load a TXT or PDF file (given as raw bytes) into text units.

    Raises:
        UnsupportedFileTypeError: extension not in ``.txt``/``.pdf``.
        EmptyDocumentError: no usable text could be extracted.
        ExtractionError: the file could not be parsed.
    """
    if not filename or not filename.lower().endswith(SUPPORTED_EXTENSIONS):
        supported = ", ".join(SUPPORTED_EXTENSIONS)
        raise UnsupportedFileTypeError(
            f"'{filename or 'file'}' is not supported. Please upload: {supported}."
        )
    if not data:
        raise EmptyDocumentError(f"'{filename}' is empty (0 bytes).")

    if filename.lower().endswith(".txt"):
        units = _load_txt(filename, data)
    else:
        units = _extract_pdf(filename, data)

    if not units:
        kind = "scanned/image-only PDF with no extractable text" if filename.lower().endswith(".pdf") else "text"
        raise EmptyDocumentError(f"'{filename}' contains no {kind}.")

    return LoadedDocument(filename=filename, units=units)
