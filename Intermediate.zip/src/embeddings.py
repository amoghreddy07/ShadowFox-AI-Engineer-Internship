"""Embedding generation, isolated from extraction and retrieval logic.

The embedder returns L2-normalized vectors so cosine similarity and dot
product are equivalent for retrieval.
"""

from __future__ import annotations

import logging

import numpy as np

from .config import DEFAULT_EMBEDDING_MODEL

logger = logging.getLogger(__name__)


class EmbeddingError(Exception):
    """Raised when the embedding model cannot be loaded or run."""


class SentenceTransformerEmbedder:
    """Wraps a sentence-transformers model behind a small ``encode`` API."""

    def __init__(self, model_name: str | None = None):
        self.model_name = model_name or DEFAULT_EMBEDDING_MODEL
        self._model = None

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def load(self) -> None:
        """Load the model (idempotent). Useful for warm-up at startup."""
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise EmbeddingError(
                "sentence-transformers is not installed. "
                "Run `pip install -r requirements.txt`."
            ) from exc
        try:
            logger.info("Loading embedding model '%s'", self.model_name)
            self._model = SentenceTransformer(self.model_name)
        except Exception as exc:  # noqa: BLE001 - surfaced as EmbeddingError
            logger.exception("Failed to load embedding model '%s'", self.model_name)
            raise EmbeddingError(
                f"Could not load embedding model '{self.model_name}'. "
                "The first run downloads the model, so check your internet connection."
            ) from exc

    def encode(self, texts: list[str]) -> np.ndarray:
        """Encode texts into an (n, dim) float32 array of unit vectors."""
        if not texts:
            return np.zeros((0, 0), dtype=np.float32)
        self.load()
        try:
            vectors = self._model.encode(
                list(texts),
                convert_to_numpy=True,
                normalize_embeddings=True,
                show_progress_bar=False,
            )
        except Exception as exc:  # noqa: BLE001 - surfaced as EmbeddingError
            logger.exception("Embedding generation failed")
            raise EmbeddingError(
                "Failed to generate embeddings for the provided text."
            ) from exc
        return np.asarray(vectors, dtype=np.float32)

    def encode_query(self, text: str) -> np.ndarray:
        """Encode a single query string into a unit vector."""
        return self.encode([text])[0]
