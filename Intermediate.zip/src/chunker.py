"""Chunking: split cleaned document text into overlapping, retrievable pieces.

Strategy (see README "Chunking strategy" for the full rationale):

* Split each text unit into paragraphs, then sentences (structure-aware,
  never a blind random split).
* Greedily pack sentences into chunks up to ``chunk_size`` characters.
* When a new chunk starts, carry over the tail of the previous chunk
  (``overlap`` characters, trimmed to a word boundary) so meaning that
  spans a boundary is not lost.
* Sentences longer than ``chunk_size`` are hard-split with the same stride.

Each chunk keeps its source filename and (for PDFs) its page number.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .document_loader import LoadedDocument

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


@dataclass
class Chunk:
    """A retrievable piece of a document with its source metadata."""

    chunk_id: int  # 1-based id within the source document
    text: str
    source: str  # original filename
    page: int | None = None  # 1-based PDF page, None for TXT

    @property
    def location(self) -> str:
        return f"Page {self.page}" if self.page is not None else f"Chunk {self.chunk_id}"


def _segment(text: str) -> list[tuple[str, str]]:
    """Split text into sentence-level pieces, each with its leading separator."""
    pieces: list[tuple[str, str]] = []
    paragraphs = [p.strip() for p in _PARAGRAPH_SPLIT.split(text) if p.strip()]
    for para_index, paragraph in enumerate(paragraphs):
        sentences = [s.strip() for s in _SENTENCE_SPLIT.split(paragraph) if s.strip()]
        for sent_index, sentence in enumerate(sentences):
            if para_index == 0 and sent_index == 0:
                separator = ""
            elif sent_index == 0:
                separator = "\n\n"
            else:
                separator = " "
            pieces.append((sentence, separator))
    return pieces


def _hard_split(piece: str, chunk_size: int, overlap: int) -> list[str]:
    """Split an oversized piece into windows of ``chunk_size`` with stride."""
    windows: list[str] = []
    start = 0
    length = len(piece)
    while start < length:
        end = min(start + chunk_size, length)
        windows.append(piece[start:end])
        if end == length:
            break
        start = end - overlap
    return windows


def _overlap_tail(text: str, overlap: int) -> str:
    """Return the trailing ``overlap`` characters, trimmed to a word boundary."""
    if overlap <= 0 or not text:
        return ""
    tail = text[-overlap:]
    space_index = tail.find(" ")
    if space_index != -1:
        tail = tail[space_index + 1 :]
    return tail.strip()


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 150) -> list[str]:
    """Split ``text`` into overlapping chunks of at most ``chunk_size`` chars."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer.")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and < chunk_size.")

    text = (text or "").strip()
    if not text:
        return []

    segments = _segment(text)
    if not segments:
        return []

    chunks: list[str] = []
    current = ""

    for piece, separator in segments:
        if len(piece) > chunk_size:
            if current:
                chunks.append(current.strip())
                current = ""
            windows = _hard_split(piece, chunk_size, overlap)
            chunks.extend(window.strip() for window in windows[:-1])
            current = windows[-1]
            continue

        candidate = current + separator + piece if current else piece
        if len(candidate) <= chunk_size:
            current = candidate
            continue

        chunks.append(current.strip())
        tail = _overlap_tail(current, overlap)
        current = f"{tail} {piece}".strip() if tail else piece
        if len(current) > chunk_size:
            current = piece

    if current.strip():
        chunks.append(current.strip())

    return [chunk for chunk in chunks if chunk]


def chunk_documents(
    documents: list[LoadedDocument], chunk_size: int = 800, overlap: int = 150
) -> list[Chunk]:
    """Chunk every unit of every document, preserving source/page metadata.

    Chunk ids are 1-based and sequential within each source document.
    PDFs are chunked page by page so page metadata stays accurate.
    """
    result: list[Chunk] = []
    for document in documents:
        chunk_id = 0
        for unit in document.units:
            for text in chunk_text(unit.text, chunk_size=chunk_size, overlap=overlap):
                chunk_id += 1
                result.append(
                    Chunk(
                        chunk_id=chunk_id,
                        text=text,
                        source=document.filename,
                        page=unit.page,
                    )
                )
    return result
