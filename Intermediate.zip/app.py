"""Streamlit UI for the Document-Based Q&A Assistant (ShadowFox Intermediate).

Pipeline: upload -> extract -> clean -> chunk -> embed -> index ->
question -> retrieve -> grounded answer + visible sources.
"""

from __future__ import annotations

import hashlib
import logging
import os

from dotenv import load_dotenv

load_dotenv()

import streamlit as st

from src.chunker import chunk_documents
from src.config import (
    DEFAULT_CHUNK_OVERLAP,
    DEFAULT_CHUNK_SIZE,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_MIN_SIMILARITY,
    DEFAULT_TOP_K,
)
from src.document_loader import DocumentError, LoadedDocument, load_document
from src.embeddings import EmbeddingError, SentenceTransformerEmbedder
from src.qa_engine import QAError, generate_answer
from src.retriever import EmptyQueryError, RetrievalError, Retriever
from src.vector_store import VectorStore, VectorStoreError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
)
logger = logging.getLogger("docqa.app")

st.set_page_config(
    page_title="DocQA - Document Q&A Assistant",
    layout="wide",
    initial_sidebar_state="expanded",
)


@st.cache_resource(show_spinner=False)
def load_embedder(model_name: str) -> SentenceTransformerEmbedder:
    """Load (and cache) the embedding model once per process."""
    embedder = SentenceTransformerEmbedder(model_name)
    embedder.load()
    return embedder


def _uploaded_signature(files) -> str:
    digest = hashlib.sha256()
    for file in files:
        digest.update(file.name.encode("utf-8", errors="replace"))
        digest.update(b"\0")
        digest.update(str(file.size).encode())
        digest.update(b"\0")
        digest.update(hashlib.sha256(file.getvalue()).digest())
    return digest.hexdigest()


def build_index(files, chunk_size: int, overlap: int, embedder):
    """Extract, chunk, embed, and index the uploaded files.

    Invalid files are collected as warnings; valid files still get indexed.
    Raises DocumentError/VectorStoreError if nothing usable remains.
    """
    documents: list[LoadedDocument] = []
    errors: list[str] = []
    for file in files:
        try:
            documents.append(load_document(file.name, file.getvalue()))
        except DocumentError as exc:
            logger.warning("Rejected '%s': %s", file.name, exc)
            errors.append(str(exc))

    if not documents:
        raise DocumentError(errors[0] if errors else "No usable documents were uploaded.")

    chunks = chunk_documents(documents, chunk_size=chunk_size, overlap=overlap)
    if not chunks:
        raise DocumentError("The uploaded documents did not produce any text chunks.")

    store = VectorStore()
    store.build(chunks, embedder)
    return documents, chunks, store, errors


def clear_index_state() -> None:
    st.session_state.docqa_documents = []
    st.session_state.docqa_chunks = []
    st.session_state.docqa_store = None
    st.session_state.docqa_errors = []
    st.session_state.docqa_answer = None
    st.session_state.docqa_results = []


_STATE_DEFAULTS = {
    "docqa_documents": [],
    "docqa_chunks": [],
    "docqa_store": None,
    "docqa_errors": [],
    "docqa_index_key": None,
    "docqa_answer": None,
    "docqa_results": [],
}
for _key, _default in _STATE_DEFAULTS.items():
    st.session_state.setdefault(_key, _default)

# ---------------------------------------------------------------- sidebar ---
with st.sidebar:
    st.title("DocQA")
    st.caption("Document-based Q&A via embeddings and retrieval (RAG).")

    uploaded_files = st.file_uploader(
        "Upload documents",
        type=["pdf", "txt"],
        accept_multiple_files=True,
        help="Supported formats: PDF and TXT. You can upload several files at once.",
    )

    st.markdown("**Index settings**")
    embedding_model = st.text_input(
        "Embedding model",
        value=DEFAULT_EMBEDDING_MODEL,
        help="Any sentence-transformers model name. Changing it rebuilds the index.",
    )
    chunk_size = st.number_input(
        "Chunk size (characters)",
        min_value=200,
        max_value=4000,
        value=DEFAULT_CHUNK_SIZE,
        step=100,
        help="Maximum size of each chunk. Changing it rebuilds the index.",
    )
    chunk_overlap = st.number_input(
        "Chunk overlap (characters)",
        min_value=0,
        max_value=2000,
        value=DEFAULT_CHUNK_OVERLAP,
        step=50,
        help="Characters shared between consecutive chunks. Changing it rebuilds the index.",
    )
    top_k = st.slider("Top-K results", min_value=1, max_value=10, value=DEFAULT_TOP_K)
    min_similarity = st.slider(
        "Min. similarity threshold",
        min_value=0.0,
        max_value=1.0,
        value=DEFAULT_MIN_SIMILARITY,
        step=0.05,
        help="Retrieved chunks below this cosine similarity are treated as weak context.",
    )

    rebuild = st.button("Rebuild index", use_container_width=True)

# ------------------------------------------------------- index (re)build ---
signature_parts = []
if uploaded_files:
    signature_parts = [_uploaded_signature(uploaded_files)]
    signature = hashlib.sha256(
        "|".join(signature_parts).encode()
        + f"|{chunk_size}|{chunk_overlap}|{embedding_model}".encode()
    ).hexdigest()

    if rebuild:
        st.session_state.docqa_index_key = None

    if signature != st.session_state.docqa_index_key:
        try:
            with st.spinner("Extracting text, chunking, embedding, and indexing..."):
                embedder = load_embedder(embedding_model)
                documents, chunks, built_store, errors = build_index(
                    uploaded_files, int(chunk_size), int(chunk_overlap), embedder
                )
            st.session_state.docqa_documents = documents
            st.session_state.docqa_chunks = chunks
            st.session_state.docqa_store = built_store
            st.session_state.docqa_errors = errors
            st.session_state.docqa_index_key = signature
            st.session_state.docqa_answer = None
            st.session_state.docqa_results = []
            logger.info("Indexed %d chunks from %d document(s)", len(chunks), len(documents))
        except (DocumentError, VectorStoreError, EmbeddingError) as exc:
            logger.error("Index build failed: %s", exc)
            clear_index_state()
            st.session_state.docqa_errors = [str(exc)]
            st.session_state.docqa_index_key = signature
            st.error(f"Could not build the index: {exc}")
elif st.session_state.docqa_index_key is not None:
    clear_index_state()
    st.session_state.docqa_index_key = None
    st.session_state.docqa_errors = []

# -------------------------------------------------------- sidebar status ---
# Rendered after the build block so status/warnings reflect this run.
with st.sidebar:
    st.markdown("---")
    st.markdown("**Status**")
    store = st.session_state.docqa_store
    if store is not None:
        n_docs = len({c.source for c in st.session_state.docqa_chunks})
        st.success(
            f"Index ready: {len(store)} chunks from {n_docs} document(s) "
            f"({store.backend} backend)"
        )
        for document in st.session_state.docqa_documents:
            count = sum(
                1 for c in st.session_state.docqa_chunks if c.source == document.filename
            )
            st.write(f"- {document.filename}: {count} chunks")
    elif not uploaded_files:
        st.info("No index yet. Upload PDF/TXT documents to begin.")
    elif not st.session_state.docqa_errors:
        st.info("Building the index...")

    for warning in st.session_state.docqa_errors:
        st.warning(warning)

    if not os.getenv("GROQ_API_KEY"):
        st.warning(
            "GROQ_API_KEY is not set. Retrieval works, but answer generation "
            "needs a key (see .env.example)."
        )

    st.markdown("---")
    st.caption(
        "Pipeline: upload -> extract -> clean -> chunk -> embed -> index -> "
        "retrieve -> grounded answer."
    )

# ------------------------------------------------------------------ main ----
st.title("Document-Based Q&A Assistant")
st.markdown(
    "Upload one or more **PDF/TXT** documents in the sidebar, ask a question, "
    "and receive an answer **grounded in the retrieved passages** - with the "
    "supporting sources shown underneath."
)
st.markdown(
    "`Upload -> Extract -> Clean -> Chunk -> Embed -> Index -> "
    "Question -> Retrieve Top-K -> Grounded Answer + Sources`"
)

store = st.session_state.docqa_store

with st.form("question_form"):
    question = st.text_area(
        "Ask a question about your documents",
        height=100,
        placeholder="e.g. What does the document say about ...?",
    )
    submitted = st.form_submit_button("Ask")

if submitted:
    st.session_state.docqa_answer = None
    st.session_state.docqa_results = []

    if store is None or not st.session_state.docqa_chunks:
        st.error("Upload at least one valid document and build the index first.")
    elif not question or not question.strip():
        st.warning("Please enter a question (the question cannot be empty).")
    else:
        retriever = Retriever(
            embedder=load_embedder(embedding_model),
            vector_store=store,
            top_k=top_k,
            min_similarity=min_similarity,
        )
        try:
            with st.spinner("Retrieving relevant passages..."):
                results = retriever.retrieve(question)
                candidates = (
                    results
                    if results
                    else retriever.search(question)
                )
        except EmptyQueryError as exc:
            st.warning(str(exc))
        except RetrievalError as exc:
            logger.error("Retrieval failed: %s", exc)
            st.error(f"Retrieval failed: {exc}")
        else:
            if not results:
                st.session_state.docqa_results = candidates
                st.info(
                    f"No sufficiently relevant passages were found "
                    f"(best similarity below the {min_similarity:.2f} threshold). "
                    "The uploaded documents may not contain this information, so "
                    "no answer was generated from model memory."
                )
            else:
                try:
                    with st.spinner("Generating a grounded answer..."):
                        answer = generate_answer(question, results)
                except QAError as exc:
                    logger.error("Answer generation failed: %s", exc)
                    st.error(str(exc))
                else:
                    st.session_state.docqa_answer = answer
                    st.session_state.docqa_results = results

# ------------------------------------------------------------- results ------
if st.session_state.docqa_answer:
    st.subheader("Answer")
    st.markdown(st.session_state.docqa_answer)

if st.session_state.docqa_results:
    results = st.session_state.docqa_results
    below_threshold = (
        not st.session_state.docqa_answer
        or (results and results[0].score < min_similarity)
    )
    st.subheader("Retrieved Sources")
    if below_threshold:
        st.caption(
            "Shown for transparency - these passages scored below the similarity "
            "threshold and were not used to generate an answer."
        )
    for index, item in enumerate(results, start=1):
        chunk = item.chunk
        location = f"Page {chunk.page}" if chunk.page is not None else f"Chunk {chunk.chunk_id}"
        with st.container(border=True):
            st.markdown(f"**{index}. {chunk.source}** - {location} - Similarity: `{item.score:.3f}`")
            st.text(chunk.text)
