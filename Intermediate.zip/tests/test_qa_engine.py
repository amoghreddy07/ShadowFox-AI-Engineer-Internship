"""Tests for prompt construction and grounded answer generation (no real API)."""

from __future__ import annotations

import pytest

from src.chunker import Chunk
from src.config import DEFAULT_LLM_MODEL
from src.qa_engine import (
    SYSTEM_PROMPT,
    AnswerGenerationError,
    MissingAPIKeyError,
    QAError,
    build_messages,
    format_context,
    generate_answer,
)
from src.retriever import RetrievedChunk

from conftest import FakeClient


def sample_results() -> list[RetrievedChunk]:
    return [
        RetrievedChunk(
            chunk=Chunk(
                chunk_id=12,
                text="Gradient descent updates model weights to minimize loss.",
                source="ml_notes.pdf",
                page=4,
            ),
            score=0.82,
        ),
        RetrievedChunk(
            chunk=Chunk(
                chunk_id=3,
                text="Learning rate controls the step size of each update.",
                source="tips.txt",
                page=None,
            ),
            score=0.71,
        ),
    ]


# ----------------------------------------------------------------- prompt ---


def test_system_prompt_enforces_grounding():
    assert "ONLY" in SYSTEM_PROMPT
    assert "do not invent" in SYSTEM_PROMPT.lower()
    assert "outside" in SYSTEM_PROMPT.lower()
    assert "do not contain enough information" in SYSTEM_PROMPT


def test_format_context_includes_source_page_chunk_similarity():
    text = format_context(sample_results())
    assert "Source: ml_notes.pdf" in text
    assert "Page: 4" in text
    assert "Chunk: 12" in text
    assert "Similarity: 0.820" in text
    assert "Source: tips.txt" in text
    assert "Chunk: 3" in text
    assert "Gradient descent" in text


def test_build_messages_separates_question_from_context():
    messages = build_messages("How do models learn?", sample_results())
    assert messages[0]["role"] == "system"
    assert messages[0]["content"] == SYSTEM_PROMPT
    user = messages[1]["content"]
    assert "RETRIEVED CONTEXT:" in user
    assert "QUESTION:" in user
    assert user.index("RETRIEVED CONTEXT:") < user.index("QUESTION:")
    assert "How do models learn?" in user
    assert "Gradient descent" in user
    assert "[1] Source: ml_notes.pdf" in user


# ------------------------------------------------------------ generation ---


def test_generate_answer_uses_client_and_returns_content():
    client = FakeClient(content="  Grounded answer.  ")
    answer = generate_answer("How do models learn?", sample_results(), client=client)
    assert answer == "Grounded answer."
    assert "QUESTION:" in client.last_messages[1]["content"]


def test_missing_api_key_raises(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    with pytest.raises(MissingAPIKeyError) as excinfo:
        generate_answer("What is this?", sample_results(), api_key=None, client=None)
    assert "GROQ_API_KEY" in str(excinfo.value)


def test_groq_client_configured_from_env(monkeypatch):
    """The official Groq SDK client gets GROQ_API_KEY and GROQ_MODEL from env."""
    import groq as groq_module
    from types import SimpleNamespace

    captured: dict = {"messages": None, "model": None, "api_key": None}

    class StubGroq:
        def __init__(self, api_key=None, **kwargs):
            captured["api_key"] = api_key
            captured["client_kwargs"] = kwargs
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(create=self._create)
            )

        def _create(self, *, model, messages, **kwargs):
            captured["model"] = model
            captured["messages"] = messages
            message = SimpleNamespace(content="stubbed grounded answer")
            return SimpleNamespace(choices=[SimpleNamespace(message=message)])

    monkeypatch.setattr(groq_module, "Groq", StubGroq)
    monkeypatch.setenv("GROQ_API_KEY", "gsk_test_key_123")
    monkeypatch.setenv("GROQ_MODEL", "llama-3.1-8b-instant")

    answer = generate_answer("How do models learn?", sample_results())

    assert answer == "stubbed grounded answer"
    assert captured["api_key"] == "gsk_test_key_123"
    assert captured["model"] == "llama-3.1-8b-instant"
    user_prompt = captured["messages"][1]["content"]
    assert "RETRIEVED CONTEXT:" in user_prompt
    assert "Gradient descent" in user_prompt
    assert "QUESTION:" in user_prompt


def test_groq_model_falls_back_to_default(monkeypatch):
    import groq as groq_module
    from types import SimpleNamespace

    captured: dict = {}

    class StubGroq:
        def __init__(self, api_key=None, **kwargs):
            self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

        def _create(self, *, model, messages, **kwargs):
            captured["model"] = model
            message = SimpleNamespace(content="ok")
            return SimpleNamespace(choices=[SimpleNamespace(message=message)])

    monkeypatch.setattr(groq_module, "Groq", StubGroq)
    monkeypatch.setenv("GROQ_API_KEY", "gsk_test_key_123")
    monkeypatch.delenv("GROQ_MODEL", raising=False)

    generate_answer("What is this?", sample_results())
    assert captured["model"] == DEFAULT_LLM_MODEL


def test_groq_authentication_error_is_friendly():
    class AuthenticationError(Exception):
        pass

    client = FakeClient(error=AuthenticationError("invalid api key"))
    with pytest.raises(AnswerGenerationError) as excinfo:
        generate_answer("What is this?", sample_results(), client=client)
    assert "GROQ_API_KEY" in str(excinfo.value)
    assert "invalid api key" not in str(excinfo.value)


def test_empty_question_rejected():
    with pytest.raises(QAError):
        generate_answer("   ", sample_results(), client=FakeClient())


def test_no_retrieved_context_rejected():
    with pytest.raises(QAError):
        generate_answer("What is this?", [], client=FakeClient())


def test_api_failure_raises_friendly_error():
    client = FakeClient(error=RuntimeError("connection reset by peer"))
    with pytest.raises(AnswerGenerationError) as excinfo:
        generate_answer("What is this?", sample_results(), client=client)
    assert "connection reset" not in str(excinfo.value)


def test_rate_limit_error_is_recognized():
    class RateLimitError(Exception):
        pass

    client = FakeClient(error=RateLimitError("429 too many requests"))
    with pytest.raises(AnswerGenerationError) as excinfo:
        generate_answer("What is this?", sample_results(), client=client)
    assert "rate limit" in str(excinfo.value).lower()


def test_empty_model_response_raises():
    with pytest.raises(AnswerGenerationError):
        generate_answer("What is this?", sample_results(), client=FakeClient(content="   "))
