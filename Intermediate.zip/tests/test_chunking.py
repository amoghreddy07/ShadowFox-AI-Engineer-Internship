"""Tests for the chunking strategy: sizes, overlap, metadata, validation."""

from __future__ import annotations

import pytest

from src.chunker import Chunk, chunk_documents, chunk_text
from src.document_loader import LoadedDocument, TextUnit

SENTENCES = [
    f"Sentence number {i} explains a distinct idea about machine learning."
    for i in range(1, 40)
]
LONG_TEXT = "\n\n".join(
    " ".join(SENTENCES[i : i + 3]) for i in range(0, len(SENTENCES), 3)
)


def test_empty_text_returns_no_chunks():
    assert chunk_text("") == []
    assert chunk_text("   \n  ") == []
    assert chunk_text(None) == []


def test_all_chunks_respect_chunk_size():
    chunks = chunk_text(LONG_TEXT, chunk_size=300, overlap=60)
    assert len(chunks) > 1
    assert all(len(c) <= 300 for c in chunks)
    assert all(c.strip() for c in chunks)


def test_splits_happen_at_word_boundaries():
    """Structure-aware splitting never cuts inside a word."""
    chunks = chunk_text(LONG_TEXT, chunk_size=300, overlap=60)
    vocabulary = set(LONG_TEXT.split())
    for chunk in chunks:
        tokens = chunk.split()
        assert tokens[0] in vocabulary, f"chunk starts mid-word: {tokens[0]!r}"
        assert tokens[-1] in vocabulary, f"chunk ends mid-word: {tokens[-1]!r}"


def test_overlap_between_consecutive_chunks():
    chunks = chunk_text(LONG_TEXT, chunk_size=300, overlap=60)
    for previous, following in zip(chunks, chunks[1:]):
        # The next chunk begins with a word-boundary-trimmed tail of the previous one.
        assert following[:25] in previous


def test_oversized_piece_is_hard_split_with_stride():
    long_word_stream = " ".join(f"word{i}" for i in range(500))
    chunks = chunk_text(long_word_stream, chunk_size=100, overlap=20)
    assert len(chunks) > 3
    assert all(len(c) <= 100 for c in chunks)
    # Stride windows of size 100/overlap 20 share the region [80, 100).
    shared = long_word_stream[85:95]
    assert shared in chunks[0] and shared in chunks[1]


def test_invalid_chunk_parameters_raise():
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size=0, overlap=0)
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size=100, overlap=100)
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size=100, overlap=-1)


def test_chunk_documents_preserves_source_page_and_ids():
    doc_a = LoadedDocument(
        filename="notes.txt",
        units=[TextUnit(text=" ".join(SENTENCES), page=None)],
    )
    doc_b = LoadedDocument(
        filename="book.pdf",
        units=[
            TextUnit(text=" ".join(SENTENCES[:20]), page=3),
            TextUnit(text=" ".join(SENTENCES[20:]), page=4),
        ],
    )
    chunks = chunk_documents([doc_a, doc_b], chunk_size=250, overlap=50)

    assert chunks, "expected chunks from both documents"
    sources = {c.source for c in chunks}
    assert sources == {"notes.txt", "book.pdf"}

    txt_ids = [c.chunk_id for c in chunks if c.source == "notes.txt"]
    assert txt_ids == list(range(1, len(txt_ids) + 1)), "ids must be 1-based per source"

    pdf_pages = {c.page for c in chunks if c.source == "book.pdf"}
    assert pdf_pages == {3, 4}

    for chunk in chunks:
        assert isinstance(chunk, Chunk)
        assert chunk.text and chunk.source


def test_chunk_location_property():
    assert Chunk(chunk_id=1, text="x", source="a.txt", page=None).location == "Chunk 1"
    assert Chunk(chunk_id=1, text="x", source="a.pdf", page=4).location == "Page 4"
