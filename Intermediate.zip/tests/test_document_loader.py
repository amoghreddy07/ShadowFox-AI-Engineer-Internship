"""Tests for document ingestion: TXT/PDF extraction, validation, errors."""

from __future__ import annotations

import pytest

from src.document_loader import (
    EmptyDocumentError,
    ExtractionError,
    UnsupportedFileTypeError,
    clean_text,
    load_document,
)


def build_pdf(stream_content: bytes) -> bytes:
    """Build a minimal valid single-page PDF containing a raw content stream."""
    objects: list[bytes] = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [4 0 R] /Count 1 >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 3 0 R >> >> /Contents 5 0 R >>",
        b"<< /Length " + str(len(stream_content)).encode() + b" >>\nstream\n"
        + stream_content
        + b"\nendstream",
    ]

    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for number, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{number} 0 obj\n".encode() + body + b"\nendobj\n"
    xref_pos = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for offset in offsets:
        out += f"{offset:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_pos}\n%%EOF"
    ).encode()
    return bytes(out)


# ------------------------------------------------------------------- TXT ---


def test_load_txt_utf8():
    doc = load_document("notes.txt", "Hello world.\nSecond line.".encode("utf-8"))
    assert doc.filename == "notes.txt"
    assert len(doc.units) == 1
    assert "Hello world." in doc.units[0].text
    assert doc.units[0].page is None


def test_load_txt_uppercase_extension():
    doc = load_document("NOTES.TXT", "content".encode("utf-8"))
    assert doc.filename == "NOTES.TXT"


def test_load_txt_cp1252_encoding():
    doc = load_document("latin.txt", "café naïve".encode("cp1252"))
    assert "café" in doc.units[0].text


def test_load_txt_utf8_bom():
    doc = load_document("bom.txt", "﻿BOM heading".encode("utf-8"))
    assert doc.units[0].text.startswith("BOM heading")


def test_empty_txt_rejected():
    with pytest.raises(EmptyDocumentError):
        load_document("empty.txt", b"")


def test_whitespace_only_txt_rejected():
    with pytest.raises(EmptyDocumentError):
        load_document("blank.txt", b"   \n\n\t  \n")


def test_unsupported_file_type_rejected():
    with pytest.raises(UnsupportedFileTypeError):
        load_document("report.docx", b"anything")
    with pytest.raises(UnsupportedFileTypeError):
        load_document("image.png", b"\x89PNG")


# ------------------------------------------------------------------- PDF ---


def test_load_pdf_extracts_text_with_page_number():
    content = b"BT /F1 24 Tf 72 720 Td (Hello ShadowFox PDF) Tj ET"
    doc = load_document("sample.pdf", build_pdf(content))
    assert doc.filename == "sample.pdf"
    assert len(doc.units) >= 1
    assert "Hello ShadowFox PDF" in doc.units[0].text
    assert doc.units[0].page == 1


def test_pdf_with_no_text_rejected():
    with pytest.raises(EmptyDocumentError):
        load_document("blank.pdf", build_pdf(b"BT ET"))


def test_corrupt_pdf_rejected():
    with pytest.raises((ExtractionError, EmptyDocumentError)):
        load_document("broken.pdf", b"%PDF-1.4 this is not really a pdf")


# ---------------------------------------------------------------- clean ---


def test_clean_text_normalizes_whitespace():
    raw = "Line one.  \r\n\r\n\r\n\r\nLine\ttwo\x00done."
    cleaned = clean_text(raw)
    assert "\r" not in cleaned
    assert "\x00" not in cleaned
    assert "\n\n\n" not in cleaned
    assert cleaned == "Line one.\n\nLine two done."
