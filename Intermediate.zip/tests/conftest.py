"""Shared test fixtures: path setup, fake embedder, fake LLM client.

Keeps the suite fast, offline, and free of paid API calls.
"""

from __future__ import annotations

import hashlib
import pathlib
import re
import sys
from types import SimpleNamespace

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))


class HashingEmbedder:
    """Deterministic bag-of-words embedder (cosine ~= word overlap)."""

    def __init__(self, dim: int = 256):
        self.dim = dim
        self.model_name = "hashing-test-embedder"
        self.is_loaded = True

    def load(self) -> None:
        return None

    def encode(self, texts: list[str]) -> np.ndarray:
        vectors = np.zeros((len(texts), self.dim), dtype=np.float32)
        for row, text in enumerate(texts):
            for token in re.findall(r"[a-z0-9]+", (text or "").lower()):
                bucket = int(hashlib.md5(token.encode()).hexdigest(), 16) % self.dim
                vectors[row, bucket] += 1.0
            norm = float(np.linalg.norm(vectors[row]))
            if norm > 0:
                vectors[row] /= norm
        return vectors


class FailingEmbedder:
    """Embedder that always fails, for error-path tests."""

    def __init__(self):
        self.model_name = "failing-embedder"
        self.is_loaded = True

    def load(self) -> None:
        return None

    def encode(self, texts: list[str]) -> np.ndarray:
        from src.embeddings import EmbeddingError

        raise EmbeddingError("embedding backend unavailable")


class FakeCompletions:
    def __init__(self, parent: "FakeClient"):
        self._parent = parent

    def create(self, *, model, messages, **kwargs):
        self._parent.last_model = model
        self._parent.last_messages = messages
        if self._parent.error is not None:
            raise self._parent.error
        message = SimpleNamespace(content=self._parent.content)
        return SimpleNamespace(choices=[SimpleNamespace(message=message)])


class FakeClient:
    """Duck-typed stand-in for the Groq chat completions client (qa_engine tests)."""

    def __init__(
        self,
        content: str | None = "The answer from context.",
        error: Exception | None = None,
    ):
        self.content = content
        self.error = error
        self.last_model = None
        self.last_messages = None
        self.chat = SimpleNamespace(completions=FakeCompletions(self))
