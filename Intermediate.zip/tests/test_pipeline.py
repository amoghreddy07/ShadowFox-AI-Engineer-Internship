"""End-to-end pipeline test: load -> chunk -> embed -> retrieve -> answer.

Uses the real embedding model (skipped if it cannot be loaded) and a fake
LLM client, so no paid API call is ever made.
"""

from __future__ import annotations

import pytest

from src.chunker import chunk_documents
from src.document_loader import load_document
from src.embeddings import EmbeddingError, SentenceTransformerEmbedder
from src.qa_engine import QAError, generate_answer
from src.retriever import Retriever
from src.vector_store import VectorStore

from conftest import FakeClient
from test_document_loader import build_pdf


@pytest.fixture(scope="module")
def embedder():
    model = SentenceTransformerEmbedder()
    try:
        model.load()
    except EmbeddingError as exc:
        pytest.skip(f"embedding model unavailable: {exc}")
    return model


APOLLO_TXT = (
    "The Apollo program landed the first humans on the Moon in 1969. "
    "Neil Armstrong was the first person to walk on the lunar surface. "
    "Mission success depended on orbital mechanics, navigation, and life support engineering. "
    "The command module stayed in lunar orbit while the lander descended. "
) * 6

RAG_PDF_STREAM = (
    b"BT /F1 12 Tf 72 720 Td "
    b"(Retrieval augmented generation uses vector search to find relevant passages) Tj ET"
)


def test_full_pipeline_txt_and_pdf(embedder):
    documents = [
        load_document("apollo.txt", APOLLO_TXT.encode("utf-8")),
        load_document("rag.pdf", build_pdf(RAG_PDF_STREAM)),
    ]
    chunks = chunk_documents(documents, chunk_size=400, overlap=80)
    assert {c.source for c in chunks} == {"apollo.txt", "rag.pdf"}

    store = VectorStore()
    store.build(chunks, embedder)
    assert len(store) == len(chunks)

    retriever = Retriever(embedder, store, top_k=2, min_similarity=0.1)
    question = "Who was the first person to walk on the Moon?"
    results = retriever.retrieve(question)
    assert results, "expected relevant chunks for an answerable question"
    assert results[0].chunk.source == "apollo.txt"

    client = FakeClient(content="Neil Armstrong, according to the uploaded document.")
    answer = generate_answer(question, results, client=client)
    assert "Neil Armstrong" in answer

    # The LLM call must have carried the retrieved context, not just the question.
    payload = client.last_messages[1]["content"]
    assert "RETRIEVED CONTEXT:" in payload
    assert "apollo.txt" in payload


def test_unanswerable_question_yields_no_grounded_answer(embedder):
    documents = [load_document("apollo.txt", APOLLO_TXT.encode("utf-8"))]
    chunks = chunk_documents(documents, chunk_size=400, overlap=80)
    store = VectorStore()
    store.build(chunks, embedder)

    retriever = Retriever(embedder, store, top_k=2, min_similarity=0.9)
    results = retriever.retrieve("What is the recipe for chocolate cake?")
    assert results == [], "unanswerable question should be filtered as weak context"
    with pytest.raises(QAError):
        generate_answer("What is the recipe for chocolate cake?", results, client=FakeClient())
