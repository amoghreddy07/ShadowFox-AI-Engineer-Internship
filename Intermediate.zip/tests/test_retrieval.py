"""Tests for vector indexing and similarity retrieval (no LLM involved)."""

from __future__ import annotations

import numpy as np
import pytest

from src.chunker import Chunk
from src.retriever import EmptyQueryError, RetrievalError, Retriever
from src.vector_store import VectorStore, VectorStoreError

from conftest import FailingEmbedder, HashingEmbedder

CORPUS = [
    Chunk(
        chunk_id=1,
        text="Photosynthesis is the process plants use to convert sunlight into chemical energy.",
        source="biology.pdf",
        page=3,
    ),
    Chunk(
        chunk_id=2,
        text="The French Revolution began in 1789 and reshaped European politics.",
        source="history.pdf",
        page=12,
    ),
    Chunk(
        chunk_id=3,
        text="Python is a popular programming language for data science and scripting.",
        source="programming.txt",
        page=None,
    ),
    Chunk(
        chunk_id=4,
        text="Vaccines train the immune system to recognize pathogens safely.",
        source="biology.pdf",
        page=9,
    ),
]


def build_store(chunks=None) -> VectorStore:
    store = VectorStore()
    store.build(chunks or CORPUS, HashingEmbedder())
    return store


def test_build_and_search_returns_sorted_scores():
    store = build_store()
    assert len(store) == len(CORPUS)
    assert store.backend in {"faiss", "numpy"}
    retriever = Retriever(HashingEmbedder(), store, top_k=3, min_similarity=0.0)
    results = retriever.search("How do plants make food from sunlight?")
    assert 1 <= len(results) <= 3
    scores = [r.score for r in results]
    assert scores == sorted(scores, reverse=True)


def test_retrieval_finds_topically_relevant_chunk():
    store = build_store()
    retriever = Retriever(HashingEmbedder(), store, top_k=2, min_similarity=0.05)
    results = retriever.retrieve("What is photosynthesis in plants?")
    assert results, "expected at least one relevant chunk"
    assert results[0].chunk.source == "biology.pdf"
    assert results[0].chunk.page == 3


def test_multi_document_retrieval_keeps_source_metadata():
    store = build_store()
    retriever = Retriever(HashingEmbedder(), store, top_k=4, min_similarity=0.0)
    results = retriever.search("programming language python and photosynthesis plants")
    assert results
    for item in results:
        assert item.chunk.source in {c.source for c in CORPUS}
        assert item.chunk.text
        assert item.chunk.chunk_id >= 1


def test_top_k_limits_results():
    store = build_store()
    retriever = Retriever(HashingEmbedder(), store, top_k=2, min_similarity=0.0)
    assert len(retriever.search("anything about history or biology")) <= 2


def test_min_similarity_filters_weak_context():
    store = build_store()
    retriever = Retriever(HashingEmbedder(), store, top_k=4, min_similarity=0.99)
    kept = retriever.retrieve("quantum blockchain teleportation cookies")
    assert kept == [], "weak matches must be filtered out"
    # The unfiltered view is still available for transparency in the UI.
    assert retriever.search("quantum blockchain teleportation cookies")


def test_empty_query_rejected():
    store = build_store()
    retriever = Retriever(HashingEmbedder(), store)
    with pytest.raises(EmptyQueryError):
        retriever.retrieve("")
    with pytest.raises(EmptyQueryError):
        retriever.retrieve("    \n  ")


def test_embedding_failure_surfaces_as_retrieval_error():
    store = build_store()
    retriever = Retriever(FailingEmbedder(), store)
    with pytest.raises(RetrievalError):
        retriever.search("anything")


def test_query_dimension_mismatch_raises():
    store = build_store()
    with pytest.raises(VectorStoreError):
        store.search(np.ones(7, dtype=np.float32), top_k=2)


def test_empty_store_returns_nothing():
    store = VectorStore()
    assert store.search(np.ones(8, dtype=np.float32), top_k=2) == []
    with pytest.raises(VectorStoreError):
        store.build([], HashingEmbedder())
