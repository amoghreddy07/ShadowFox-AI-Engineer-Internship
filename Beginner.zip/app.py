import os
import io
from flask import Flask, render_template, request, jsonify
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

MODEL = os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b")

MAX_INPUT_LENGTH = 50000
ALLOWED_EXTENSIONS = {"pdf", "docx", "txt", "md"}
MAX_FILE_SIZE_MB = 10

PROMPTS = {
    "summarize": {
        "system": (
            "You are an expert academic assistant helping students study effectively. "
            "Your task is to summarize the given notes into clear, concise key points. "
            "Use bullet points and highlight the most important concepts. "
            "Keep the summary organized and easy to review before an exam."
        ),
        "user_template": (
            "Please summarize the following notes into key points:\n\n{input}"
        ),
    },
    "quiz": {
        "system": (
            "You are a quiz creation assistant for students. "
            "Generate quiz questions based on the provided study material "
            "to help students test their understanding. "
            "Create a mix of multiple choice questions (with 4 options each, "
            "mark the correct answer with an asterisk *) and short answer questions. "
            "Include 3-5 questions total."
        ),
        "user_template": (
            "Generate quiz questions from the following study material:\n\n{input}"
        ),
    },
    "explain": {
        "system": (
            "You are a patient tutor who explains concepts clearly. "
            "Break down complex ideas into simple, understandable language suitable for a student. "
            "Start with a simple definition, provide a real-world analogy, "
            "and then give a brief example to solidify understanding."
        ),
        "user_template": (
            "Explain the following concept clearly for a student:\n\n{input}"
        ),
    },
    "improve": {
        "system": (
            "You are an expert academic writing assistant helping students improve their answers. "
            "Take the student's existing answer and make it clearer, more complete, and better structured. "
            "Fix any factual errors, fill in missing information, improve explanations, "
            "and ensure the answer directly addresses the question. "
            "Keep the student's original ideas but enhance the quality of the response."
        ),
        "user_template": (
            "Question: {question}\n\n"
            "Student's current answer:\n{input}\n\n"
            "Please improve this answer to be clearer and more complete."
        ),
    },
}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text_from_pdf(file_bytes):
    from PyPDF2 import PdfReader
    reader = PdfReader(io.BytesIO(file_bytes))
    text = ""
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"
    return text.strip()


def extract_text_from_docx(file_bytes):
    from docx import Document
    doc = Document(io.BytesIO(file_bytes))
    text = "\n".join(para.text for para in doc.paragraphs if para.text.strip())
    return text.strip()


def extract_text_from_file(file_bytes, filename):
    ext = filename.rsplit(".", 1)[1].lower()
    if ext == "pdf":
        return extract_text_from_pdf(file_bytes)
    elif ext == "docx":
        return extract_text_from_docx(file_bytes)
    elif ext in ("txt", "md"):
        return file_bytes.decode("utf-8", errors="replace").strip()
    return ""


def build_prompt(user_input, feature, question=None):
    prompt_config = PROMPTS[feature]
    if feature == "improve" and question:
        user_content = prompt_config["user_template"].format(question=question, input=user_input)
    else:
        user_content = prompt_config["user_template"].format(input=user_input)
    return [
        {"role": "system", "content": prompt_config["system"]},
        {"role": "user", "content": user_content},
    ]


def get_client():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise ValueError("GROQ_API_KEY is not set. Please configure it in your .env file.")
    return Groq(api_key=api_key)


def call_llm(messages):
    client = get_client()
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        temperature=0.5,
        max_tokens=1500,
    )
    return response.choices[0].message.content


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided."}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": f"Unsupported file type. Please upload: {', '.join(sorted(ALLOWED_EXTENSIONS))}."}), 400

    file_bytes = file.read()
    if len(file_bytes) > MAX_FILE_SIZE_MB * 1024 * 1024:
        return jsonify({"error": f"File is too large. Maximum size is {MAX_FILE_SIZE_MB}MB."}), 400

    try:
        text = extract_text_from_file(file_bytes, file.filename)
        if not text:
            return jsonify({"error": "Could not extract text from the file. Please try a different file or paste your text directly."}), 400
        return jsonify({"text": text, "filename": file.filename})
    except Exception as e:
        return jsonify({"error": "Failed to process the file. Please try again."}), 500


@app.route("/api/generate", methods=["POST"])
def generate():
    data = request.get_json()

    if not data or "input" not in data or "feature" not in data:
        return jsonify({"error": "Missing required fields: 'input' and 'feature'."}), 400

    user_input = data["input"].strip()
    feature = data["feature"]

    if feature not in PROMPTS:
        return jsonify({"error": "Invalid feature. Choose from: summarize, quiz, explain, improve."}), 400

    if not user_input:
        return jsonify({"error": "Input cannot be empty. Please enter some text."}), 400

    if len(user_input) > MAX_INPUT_LENGTH:
        return jsonify({"error": f"Input is too long. Please keep it under {MAX_INPUT_LENGTH:,} characters."}), 400

    # For improve feature, we need the question field
    question = data.get("question", "").strip() if feature == "improve" else None
    if feature == "improve" and not question:
        return jsonify({"error": "Please provide a question for the Improve Answer feature."}), 400

    try:
        messages = build_prompt(user_input, feature, question=question)
        result = call_llm(messages)
        return jsonify({"result": result})
    except Exception as e:
        error_message = "An error occurred while generating the response. Please try again."
        error_str = str(e).lower()
        if "api key" in error_str or "authentication" in error_str or "credentials" in error_str:
            error_message = "API key is missing or invalid. Please check your GROQ_API_KEY in the .env file."
        elif "rate" in error_str:
            error_message = "Rate limit exceeded. Please wait a moment and try again."
        elif "timeout" in error_str or "network" in error_str or "connection" in error_str:
            error_message = "Network error. Please check your internet connection and try again."
        return jsonify({"error": error_message}), 500


if __name__ == "__main__":
    if not os.getenv("GROQ_API_KEY"):
        print("WARNING: GROQ_API_KEY is not set. Please configure it in your .env file.")
    app.run(debug=True, port=5000)
