/* ========================================
   StudyGrinder — Frontend Logic
   ======================================== */

// Configure marked for safe rendering
marked.setOptions({
    breaks: true,
    gfm: true,
});

// DOM Elements
const startBtn = document.getElementById("startBtn");
const workspace = document.getElementById("workspace");
const toolCards = document.querySelectorAll(".tool-card");
const inputTabs = document.querySelectorAll(".input-tab");
const textPanel = document.getElementById("textPanel");
const uploadPanel = document.getElementById("uploadPanel");
const userInput = document.getElementById("userInput");
const wordCount = document.getElementById("wordCount");
const uploadZone = document.getElementById("uploadZone");
const fileInput = document.getElementById("fileInput");
const browseBtn = document.getElementById("browseBtn");
const fileReady = document.getElementById("fileReady");
const fileName = document.getElementById("fileName");
const removeFile = document.getElementById("removeFile");
const generateBtn = document.getElementById("generateBtn");
const generateBtnText = document.getElementById("generateBtnText");
const loadingIndicator = document.getElementById("loadingIndicator");
const errorMessage = document.getElementById("errorMessage");
const outputSection = document.getElementById("outputSection");
const outputContent = document.getElementById("outputContent");
const copyBtn = document.getElementById("copyBtn");
const regenerateBtn = document.getElementById("regenerateBtn");
const clearBtn = document.getElementById("clearBtn");
const questionWrapper = document.getElementById("questionWrapper");
const questionInput = document.getElementById("questionInput");

// State
let currentFeature = "summarize";
let currentMethod = "text";
let uploadedFileText = "";
let uploadedFileName = "";
let isGenerating = false;
let lastRawMarkdown = "";

// Feature button labels
const featureLabels = {
    summarize: "Summarize Notes",
    quiz: "Generate Quiz",
    explain: "Explain Concept",
    improve: "Improve Answer",
};

// ========================================
// Hero CTA — Smooth scroll to workspace
// ========================================
startBtn.addEventListener("click", () => {
    workspace.scrollIntoView({ behavior: "smooth", block: "start" });
});

// ========================================
// Tool Card Selection
// ========================================
toolCards.forEach((card) => {
    card.addEventListener("click", () => {
        toolCards.forEach((c) => c.classList.remove("active"));
        card.classList.add("active");
        currentFeature = card.dataset.feature;
        generateBtnText.textContent = featureLabels[currentFeature];

        // Show/hide question input for improve feature
        if (currentFeature === "improve") {
            questionWrapper.classList.remove("hidden");
        } else {
            questionWrapper.classList.add("hidden");
            questionInput.value = "";
        }

        hideOutput();
        hideError();
    });
});

// ========================================
// Input Method Tabs
// ========================================
inputTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
        inputTabs.forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        currentMethod = tab.dataset.method;

        textPanel.classList.toggle("active", currentMethod === "text");
        uploadPanel.classList.toggle("active", currentMethod === "upload");

        hideError();
    });
});

// ========================================
// Word Count
// ========================================
userInput.addEventListener("input", () => {
    const text = userInput.value.trim();
    const words = text ? text.split(/\s+/).length : 0;
    wordCount.textContent = `${words} word${words !== 1 ? "s" : ""}`;
});

// ========================================
// File Upload — Click
// ========================================
browseBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    fileInput.click();
});

uploadZone.addEventListener("click", () => {
    fileInput.click();
});

fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
        handleFile(fileInput.files[0]);
    }
});

// ========================================
// File Upload — Drag & Drop
// ========================================
uploadZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadZone.classList.add("drag-over");
});

uploadZone.addEventListener("dragleave", () => {
    uploadZone.classList.remove("drag-over");
});

uploadZone.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadZone.classList.remove("drag-over");
    if (e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
    }
});

// ========================================
// File Processing
// ========================================
async function handleFile(file) {
    const ext = file.name.split(".").pop().toLowerCase();
    const allowed = ["pdf", "docx", "txt", "md"];

    if (!allowed.includes(ext)) {
        showError("Unsupported file type. Please upload a PDF, DOCX, TXT, or MD file.");
        return;
    }

    if (file.size > 10 * 1024 * 1024) {
        showError("File is too large. Maximum size is 10MB.");
        return;
    }

    hideError();
    setLoading(true);

    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await fetch("/api/upload", {
            method: "POST",
            body: formData,
        });

        const data = await response.json();

        if (!response.ok) {
            showError(data.error || "Failed to upload file.");
            return;
        }

        uploadedFileText = data.text;
        uploadedFileName = data.filename;

        // Show file ready state
        fileName.textContent = data.filename;
        uploadZone.classList.add("hidden");
        fileReady.classList.remove("hidden");
    } catch (err) {
        showError("Could not connect to the server. Please check your connection and try again.");
    } finally {
        setLoading(false);
    }
}

// ========================================
// Remove File
// ========================================
removeFile.addEventListener("click", () => {
    uploadedFileText = "";
    uploadedFileName = "";
    fileInput.value = "";
    fileReady.classList.add("hidden");
    uploadZone.classList.remove("hidden");
    hideError();
});

// ========================================
// Generate
// ========================================
generateBtn.addEventListener("click", async () => {
    if (isGenerating) return;

    let inputText = "";

    if (currentMethod === "text") {
        inputText = userInput.value.trim();
        if (!inputText) {
            showError("Please enter some text before generating.");
            return;
        }
    } else {
        if (!uploadedFileText) {
            showError("Please upload a file before generating.");
            return;
        }
        inputText = uploadedFileText;
    }

    // For improve feature, we need the question
    let questionText = "";
    if (currentFeature === "improve") {
        questionText = questionInput.value.trim();
        if (!questionText) {
            showError("Please enter the question you're answering.");
            return;
        }
    }

    hideError();
    hideOutput();
    setLoading(true);
    isGenerating = true;

    try {
        const body = { input: inputText, feature: currentFeature };
        if (currentFeature === "improve") {
            body.question = questionText;
        }

        const response = await fetch("/api/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });

        const data = await response.json();

        if (!response.ok) {
            showError(data.error || "An unexpected error occurred.");
            return;
        }

        showOutput(data.result);
    } catch (err) {
        showError("Could not connect to the server. Please check your connection and try again.");
    } finally {
        setLoading(false);
        isGenerating = false;
    }
});

// ========================================
// Copy — copies raw markdown, not HTML
// ========================================
copyBtn.addEventListener("click", async () => {
    const textToCopy = lastRawMarkdown;
    try {
        await navigator.clipboard.writeText(textToCopy);
        copyBtn.innerHTML = `
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
            </svg>
            Copied!
        `;
        setTimeout(() => {
            copyBtn.innerHTML = `
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
                </svg>
                Copy
            `;
        }, 2000);
    } catch {
        const textarea = document.createElement("textarea");
        textarea.value = textToCopy;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
    }
});

// ========================================
// Regenerate
// ========================================
regenerateBtn.addEventListener("click", () => {
    generateBtn.click();
});

// ========================================
// Clear
// ========================================
clearBtn.addEventListener("click", () => {
    hideOutput();
    hideError();
});

// ========================================
// UI Helpers
// ========================================
function setLoading(isLoading) {
    generateBtn.disabled = isLoading;
    if (isLoading) {
        loadingIndicator.classList.remove("hidden");
    } else {
        loadingIndicator.classList.add("hidden");
    }
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove("hidden");
}

function hideError() {
    errorMessage.classList.add("hidden");
}

function showOutput(markdownText) {
    lastRawMarkdown = markdownText;
    const rawHtml = marked.parse(markdownText);
    const cleanHtml = DOMPurify.sanitize(rawHtml);
    outputContent.innerHTML = cleanHtml;
    outputSection.classList.remove("hidden");
    outputSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function hideOutput() {
    outputSection.classList.add("hidden");
}
