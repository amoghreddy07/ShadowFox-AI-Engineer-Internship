# StudyGrinder

An AI-powered student utility application that helps students study more effectively using LLM-based tools.

## What It Does

StudyGrinder provides four core study utilities powered by Groq's language model API:

1. **Note Summarizer** - Paste long lecture notes or textbook excerpts and get a concise, organized summary with key points highlighted.
2. **Quiz Generator** - Turn study material into practice quiz questions (multiple choice + short answer) to test your understanding.
3. **Concept Explainer** - Enter any topic or concept and receive a clear, student-friendly explanation with definitions, analogies, and examples.
4. **Answer Improver** - Paste a question and your current answer to get an improved, clearer, and more complete response.

## Why It Is Useful for Students

Students often struggle with information overload. StudyGrinder helps by:
- Condensing lengthy notes into reviewable summaries
- Auto-generating practice quizzes from study material
- Breaking down complex concepts into simple, understandable explanations
- Improving written answers to be clearer and more comprehensive

## Features

- Four AI-powered study tools in one clean interface
- Tab-based navigation to switch between features
- File upload support (PDF, DOCX, TXT, MD)
- Real-time word counting with input validation
- Loading indicator during API calls
- Graceful error handling with clear user messages
- Markdown rendering for clean, readable output
- Responsive design that works on desktop and mobile
- No user accounts or databases required

## Technology Stack

- **Backend**: Python, Flask
- **Frontend**: HTML, CSS, JavaScript (vanilla)
- **AI Integration**: Groq API (configurable model)
- **API Key Management**: python-dotenv
- **Markdown Rendering**: marked.js + DOMPurify

## How the Application Works

1. User selects a study tool (Summarize, Quiz, Explain, or Improve) via the tool cards.
2. User enters text into the textarea or uploads a file.
3. For the Improve Answer feature, user also enters the question they're answering.
4. User clicks the generate button.
5. The frontend sends the text and selected feature to the Flask backend via a POST request to `/api/generate`.
6. The backend validates the input, builds a structured prompt, and calls the Groq API.
7. The generated response is returned and displayed as rendered Markdown.

## Prompt Approach

Each feature uses a **system prompt + user prompt** structure:

- **System prompt**: Defines the AI's role (e.g., "expert academic assistant") and specific output instructions (format, constraints).
- **User prompt**: Contains the student's input embedded in a task-specific template.

Example for summarization:
- System: "You are an expert academic assistant... Use bullet points and highlight the most important concepts."
- User: "Please summarize the following notes into key points:\n\n{user's notes}"

## Validation and Error Handling

- **Empty input**: Prevented on both frontend and backend.
- **Invalid feature**: Backend rejects unknown feature types with a clear error.
- **API key issues**: Detected and reported with a user-friendly message.
- **Rate limits**: Handled and reported to the user.
- **Network errors**: Caught on the frontend with a connection error message.
- **API failures**: All exceptions are caught; no stack traces are exposed to the user.

## How to Install Dependencies

```bash
pip install -r requirements.txt
```

## How to Configure the API Key

1. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and replace `your-groq-api-key-here` with your actual Groq API key.
3. Optionally change the model (see `.env.example` for format).

## How to Run the Application

```bash
python app.py
```

The application will start at `http://localhost:5000`. Open this URL in your browser.

## Example Usage

1. **Summarize**: Paste a page of lecture notes, click Generate, and receive bullet-point key takeaways.
2. **Quiz**: Paste a chapter excerpt, click Generate, and get 3-5 practice questions with answers.
3. **Explain**: Type "Photosynthesis", click Generate, and receive a clear explanation with a real-world analogy.
4. **Improve**: Enter a question, paste your draft answer, and receive an improved version.

## Files

```
ShadowFox/
  app.py              - Flask backend with API endpoints and prompt logic
  requirements.txt    - Python dependencies
  .env.example        - Environment variable template
  .gitignore          - Git ignore rules
  templates/
    index.html        - Main HTML page
  static/
    style.css         - Application styling
    script.js         - Frontend JavaScript logic
```